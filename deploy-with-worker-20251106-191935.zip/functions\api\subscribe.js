// Cloudflare Pages Function: POST /api/subscribe
// Sends "Thank you for Subscribing our newsletter" to the submitted email

export async function onRequest({ request, env }) {
  const cors = {
    'access-control-allow-origin': request.headers.get('origin') || '*',
    'access-control-allow-methods': 'POST, OPTIONS',
    'access-control-allow-headers': 'Content-Type',
    'content-type': 'application/json'
  };

  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }

  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), { status: 405, headers: { ...cors, 'allow': 'POST, OPTIONS' } });
  }

  try {
    const contentType = request.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return new Response(JSON.stringify({ error: 'Invalid content type' }), { status: 415, headers: cors });
    }

    const body = await request.json();
    const toEmail = (body && body.email || '').trim();
    const turnstileToken = body && body.turnstileToken;
    
    if (!toEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(toEmail)) {
      return new Response(JSON.stringify({ error: 'Invalid email' }), { status: 400, headers: cors });
    }

    if (!turnstileToken) {
      return new Response(JSON.stringify({ error: 'Security verification required' }), { status: 400, headers: cors });
    }

    // Verify Turnstile token
    const TURNSTILE_SECRET_KEY = env.TURNSTILE_SECRET_KEY;
    if (!TURNSTILE_SECRET_KEY) {
      return new Response(JSON.stringify({ error: 'Turnstile not configured' }), { status: 500, headers: cors });
    }

    const turnstileVerify = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        secret: TURNSTILE_SECRET_KEY,
        response: turnstileToken
      })
    });

    const turnstileResult = await turnstileVerify.json();
    if (!turnstileResult.success) {
      return new Response(JSON.stringify({ error: 'Security verification failed' }), { status: 403, headers: cors });
    }

    const SERVICE_ID = env.EMAILJS_SERVICE_ID;
    const TEMPLATE_ID = env.EMAILJS_TEMPLATE_ID;
    const PUBLIC_KEY = env.EMAILJS_PUBLIC_KEY;
    const PRIVATE_KEY = env.EMAILJS_PRIVATE_KEY;

    if (!SERVICE_ID || !TEMPLATE_ID || !PUBLIC_KEY || !PRIVATE_KEY) {
      return new Response(JSON.stringify({ error: 'Server not configured' }), { status: 500, headers: cors });
    }

    // EmailJS: send email with Auto-Reply template (using private key for server-side)
    const payload = {
      service_id: SERVICE_ID,
      template_id: TEMPLATE_ID,
      user_id: PUBLIC_KEY,
      accessToken: PRIVATE_KEY,
      template_params: {
        to_email: toEmail,
        reply_to: toEmail
      }
    };

    const resp = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!resp.ok) {
      const text = await resp.text();
      return new Response(JSON.stringify({ error: 'Email provider error', detail: text, sentPayload: { hasService: !!SERVICE_ID, hasTemplate: !!TEMPLATE_ID } }), { status: 502, headers: cors });
    }

    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: cors });
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Unexpected server error' }), { status: 500, headers: cors });
  }
}


