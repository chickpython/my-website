(function ($) {
    "use strict";

    // Dev tools detection and protection
    (function() {
        var devtools = {open: false, orientation: null};
        var threshold = 160;
        
        setInterval(function() {
            if (window.outerHeight - window.innerHeight > threshold || 
                window.outerWidth - window.innerWidth > threshold) {
                if (!devtools.open) {
                    devtools.open = true;
                    console.clear();
                    console.log('%cStop!', 'font-size: 50px; font-weight: bold; color: red;');
                    console.log('%cThis is a browser feature intended for developers.', 'font-size: 16px;');
                }
            } else {
                devtools.open = false;
            }
        }, 500);
        
        // Detect F12 and other dev tools shortcuts
        document.addEventListener('keydown', function(e) {
            if (e.key === 'F12' || 
                (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J')) ||
                (e.ctrlKey && e.key === 'U')) {
                e.preventDefault();
                console.clear();
                console.log('%cAccess Restricted', 'font-size: 30px; font-weight: bold; color: red;');
                return false;
            }
        });
        
        // Disable right-click context menu (optional)
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            return false;
        });
        
        // Override console methods to hide sensitive info
        var originalConsole = {
            log: console.log,
            error: console.error,
            warn: console.warn,
            info: console.info
        };
        
        console.log = function() {
            // Only allow our warning messages
            if (arguments[0] && typeof arguments[0] === 'string' && arguments[0].includes('%c')) {
                originalConsole.log.apply(console, arguments);
            }
        };
        
        console.error = function() {};
        console.warn = function() {};
        console.info = function() {};
        console.debug = function() {};
        console.trace = function() {};
    })();

    // Spinner - disabled (removed from HTML)
    // No spinner functionality needed
    
    
    // Initiate the wowjs
    new WOW().init();


    // Fixed Navbar
    $('.fixed-top').css('top', $('.top-bar').height());
    $(window).scroll(function () {
        if ($(this).scrollTop()) {
            $('.fixed-top').addClass('bg-dark').css('top', 0);
        } else {
            $('.fixed-top').removeClass('bg-dark').css('top', $('.top-bar').height());
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Header carousel
    $(".header-carousel").owlCarousel({
        autoplay: false,
        smartSpeed: 1500,
        loop: true,
        nav: true,
        dots: false,
        items: 1,
        navText : [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ]
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: false,
        smartSpeed: 1000,
        margin: 25,
        loop: true,
        center: true,
        dots: false,
        nav: true,
        navText : [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:3
            }
        }
    });

    // --- Simple Cart (localStorage) ---
    const CART_KEY = 'flt_cart';

    function readCart() {
        try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; } catch (e) { return []; }
    }

    function writeCart(items) {
        localStorage.setItem(CART_KEY, JSON.stringify(items));
        updateCartIndicators();
    }

    function addToCart(item) {
        const cart = readCart();
        const idx = cart.findIndex(i => i.id === item.id);
        if (idx >= 0) {
            cart[idx].qty += (item.qty || 1);
        } else {
            const newItem = {
                id: item.id,
                name: item.name,
                price: item.price,
                image: item.image || '',
                qty: item.qty || 1
            };
            cart.push(newItem);
        }
        writeCart(cart);
    }
    
    // Make addToCart globally accessible
    window.addToCart = addToCart;
    window.readCart = readCart;
    window.writeCart = writeCart;
    window.updateCartIndicators = updateCartIndicators;

	// Update quantity for a cart item; remove if resulting qty <= 0
	function updateCartItemQuantity(id, delta) {
		const cart = readCart();
		const idx = cart.findIndex(i => i.id === id);
		if (idx < 0) return;
		cart[idx].qty += delta;
		if (cart[idx].qty <= 0) {
			cart.splice(idx, 1);
		}
		writeCart(cart);
		renderCartPage();
	}

	// Remove an item entirely from cart
	function removeFromCart(id) {
		const cart = readCart().filter(i => i.id !== id);
		writeCart(cart);
		renderCartPage();
	}

    function updateCartIndicators() {
        const hasItems = readCart().length > 0;
        const cartLinks = $('a[href="cart.html"]');
        cartLinks.each(function(){
            const $link = $(this);
            $link.addClass('cart-link');
            if (hasItems) {
                $link.addClass('cart-has-items');
            } else {
                $link.removeClass('cart-has-items');
            }
        });
    }

    // Bind add-to-cart buttons
    $(document).on('click', '.add-to-cart', function(e){
        e.preventDefault();
        const $btn = $(this);
        const item = {
            id: $btn.data('item_id'),
            name: $btn.data('name'),
            price: parseFloat($btn.data('price')),
            qty: 1
        };
        addToCart(item);
        window.location.href = 'cart.html';
    });

    // Render cart page if present
	function renderCartPage() {
        const $container = $('#cart-container');
        if ($container.length === 0) return;
        const items = readCart();
        if (items.length === 0) {
            $container.html('<div class="text-center mx-auto mb-5" style="max-width:600px;"><h1 class="display-6 mb-3">Your cart is empty</h1><a href="product.html" class="btn btn-primary rounded-pill py-2 px-4">Browse Egg Tarts</a></div>');
            return;
        }
        let total = 0;
		let rows = items.map((i, idx) => {
			const line = i.price * i.qty; total += line;
			return `
				<tr>
					<td>${idx+1}</td>
					<td>${i.name}</td>
					<td>RM ${i.price.toFixed(2)}</td>
					<td>
						<div class="input-group input-group-sm" style="max-width: 170px;">
							<button class="btn btn-outline-secondary cart-qty-dec" type="button" data-id="${i.id}">-</button>
							<input type="text" class="form-control text-center" value="${i.qty}" readonly>
							<button class="btn btn-outline-secondary cart-qty-inc" type="button" data-id="${i.id}">+</button>
						</div>
					</td>
					<td>RM ${line.toFixed(2)}</td>
					<td class="text-end">
						<button class="btn btn-sm btn-outline-danger cart-remove" data-id="${i.id}"><i class="fa fa-trash"></i> Remove</button>
					</td>
				</tr>`;
		}).join('');
        $container.html(`
            <div class="table-responsive">
              <table class="table table-striped align-middle">
				<thead><tr><th>#</th><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th class="text-end">Actions</th></tr></thead>
                <tbody>${rows}</tbody>
				<tfoot><tr><th colspan="4" class="text-end">Total</th><th>RM ${total.toFixed(2)}</th><th></th></tr></tfoot>
              </table>
            </div>
            <div class="mt-4">
              <h4 class="mb-3">Customer Information</h4>
              <form id="checkout-form">
                <div class="row g-3 mb-3">
                  <div class="col-md-6">
                    <label class="form-label">Full Name *</label>
                    <input type="text" class="form-control" id="customer-name" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Phone Number *</label>
                    <input type="tel" class="form-control" id="customer-phone" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" id="customer-email">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Payment Method *</label>
                    <select class="form-select" id="payment-method" required>
                      <option value="Cash on Delivery">Cash on Delivery</option>
                      <option value="Online Banking">Online Banking</option>
                      <option value="E-Wallet">E-Wallet</option>
                    </select>
                  </div>
                  <div class="col-12">
                    <label class="form-label">Delivery Address (or "Self Pickup")</label>
                    <textarea class="form-control" id="delivery-address" rows="2">Self Pickup</textarea>
                  </div>
                  <div class="col-12">
                    <label class="form-label">Special Instructions (Optional)</label>
                    <textarea class="form-control" id="order-notes" rows="2"></textarea>
                  </div>
                </div>
                <div class="d-flex gap-2">
                  <a href="product.html" class="btn btn-outline-primary rounded-pill py-2 px-4">Continue Shopping</a>
                  <button type="submit" class="btn btn-primary rounded-pill py-2 px-4">
                    <i class="fa fa-check me-2"></i>Place Order
                  </button>
                </div>
              </form>
            </div>
        `);
    }

    // Initialize indicators and cart page render
	updateCartIndicators();
	renderCartPage();

	// Cart control handlers
	$(document).on('click', '.cart-qty-inc', function() {
		const id = $(this).data('id');
		updateCartItemQuantity(id, 1);
	});

	$(document).on('click', '.cart-qty-dec', function() {
		const id = $(this).data('id');
		updateCartItemQuantity(id, -1);
	});

	$(document).on('click', '.cart-remove', function() {
		const id = $(this).data('id');
		removeFromCart(id);
	});

	// Checkout form handler
	$(document).on('submit', '#checkout-form', async function(e) {
		e.preventDefault();
		
		const items = readCart();
		if (items.length === 0) {
			showValidationError('Your cart is empty! Please add items before checkout.');
			return;
		}

		const customerName = $('#customer-name').val().trim();
		const customerPhone = $('#customer-phone').val().trim();
		const customerEmail = $('#customer-email').val().trim();
		const paymentMethod = $('#payment-method').val();
		const deliveryAddress = $('#delivery-address').val().trim();
		const notes = $('#order-notes').val().trim();

		if (!customerName || !customerPhone) {
			showValidationError('Please fill in your name and phone number to complete your order.');
			return;
		}

		// Calculate total
		const totalAmount = items.reduce((sum, item) => sum + (item.price * item.qty), 0);

		// Prepare order data
		const orderData = {
			customerName: customerName,
			customerPhone: customerPhone,
			customerEmail: customerEmail,
			paymentMethod: paymentMethod,
			deliveryAddress: deliveryAddress,
			notes: notes,
			totalAmount: totalAmount,
			items: items.map(item => ({
				id: item.id,
				name: item.name,
				price: item.price,
				quantity: item.qty
			}))
		};

		try {
			const response = await fetch('/api/orders/submit', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify(orderData)
			});

			const result = await response.json();

			if (response.ok && result.success) {
				// Clear cart
				writeCart([]);
				
				// Show beautiful success modal
				showOrderSuccessModal(result.orderNumber, result.dbStatus, result.error);
			} else {
				showOrderErrorModal('Failed to submit order. Please try again or contact us directly.');
			}
		} catch (error) {
			console.error('Order submission error:', error);
			showOrderErrorModal('An error occurred. Please contact us directly at +60 12-345 6789');
		}
	});

	// Newsletter subscription handler
	function handleNewsletterSubmit(formId, emailInputId) {
		const form = $(formId);
		if (form.length === 0) return;
		
		form.on('submit', async function(e) {
			e.preventDefault();
			
			const email = $(emailInputId).val().trim();
			if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
				showValidationError('Please enter a valid email address to subscribe.');
				return;
			}
			
			// Get Turnstile token
			const turnstileWidget = $(this).find('.cf-turnstile')[0];
			const turnstileToken = turnstile.getResponse(turnstileWidget);
			
			if (!turnstileToken) {
				showNewsletterError('Please complete the security verification before subscribing.');
				return;
			}
			
			try {
				const res = await fetch('/api/subscribe', {
					method: 'POST',
					headers: { 'content-type': 'application/json' },
					body: JSON.stringify({ 
						email: email,
						turnstileToken: turnstileToken
					})
				});
				
				if (res.ok) {
					showNewsletterSuccess(email);
					$(emailInputId).val('');
					// Reset Turnstile widget
					turnstile.reset(turnstileWidget);
					return;
				}
				
				const data = await res.json().catch(() => ({}));
				const detail = data && (data.detail || data.error) ? (data.detail || data.error) : '';
				showNewsletterError('Unable to send email right now. Please try again later.' + (detail ? '<br><small>' + detail + '</small>' : ''));
				// Reset Turnstile widget
				turnstile.reset(turnstileWidget);
			} catch (err) {
				showNewsletterError('Network error. Please check your connection and try again.');
				// Reset Turnstile widget
				if (turnstileWidget) turnstile.reset(turnstileWidget);
			}
		});
	}

	// Initialize newsletter forms when document is ready
	$(document).ready(function() {
		handleNewsletterSubmit('#newsletter-form-index', '#newsletter-email-index');
		handleNewsletterSubmit('#newsletter-form-testimonial', '#newsletter-email-testimonial');
	});

	// Show beautiful order success modal
	function showOrderSuccessModal(orderNumber, dbStatus, error) {
		// Remove existing modal if any
		$('#orderSuccessModal').remove();
		
		// Determine status icon and message
		let statusIcon = '✅';
		let statusMessage = 'Saved to database';
		let statusClass = 'text-success';
		
		if (dbStatus === 'no-database') {
			statusIcon = '⚠️';
			statusMessage = 'Database not connected (order not saved)';
			statusClass = 'text-warning';
		} else if (dbStatus === 'failed') {
			statusIcon = '⚠️';
			statusMessage = 'Database error: ' + (error || 'unknown');
			statusClass = 'text-danger';
		}
		
		// Create modal HTML
		const modalHTML = `
			<div class="modal fade" id="orderSuccessModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
						<div class="modal-body text-center p-5" style="background: linear-gradient(135deg, #f4b400 0%, #e89b00 100%);">
							<div class="mb-4">
								<div style="width: 80px; height: 80px; background: white; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
									<i class="fas fa-check-circle" style="font-size: 50px; color: #28a745;"></i>
								</div>
							</div>
							<h3 class="text-white mb-3" style="font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.2);">Order Placed Successfully!</h3>
							<div class="bg-white rounded p-4 mb-3" style="box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
								<p class="mb-2" style="font-size: 18px; color: #333;">
									<strong>Order Number:</strong>
								</p>
								<p class="mb-0" style="font-size: 24px; font-weight: 700; color: #f4b400; letter-spacing: 1px;">
									${orderNumber}
								</p>
							</div>
							<div class="bg-white rounded p-3 mb-4" style="box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
								<p class="mb-0 ${statusClass}" style="font-size: 16px;">
									<span style="font-size: 20px;">${statusIcon}</span> ${statusMessage}
								</p>
							</div>
							<p class="text-white mb-4" style="font-size: 16px; line-height: 1.6;">
								We'll contact you soon to confirm your order.<br>
								Thank you for choosing Tartlicious! 🥧
							</p>
							<button type="button" class="btn btn-light btn-lg px-5 py-3 rounded-pill" data-bs-dismiss="modal" onclick="window.location.href='product.html'" style="font-weight: 600; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
								<i class="fas fa-arrow-left me-2"></i>Continue Shopping
							</button>
						</div>
					</div>
				</div>
			</div>
		`;
		
		// Add modal to body
		$('body').append(modalHTML);
		
		// Show modal
		const modal = new bootstrap.Modal(document.getElementById('orderSuccessModal'));
		modal.show();
		
		// Redirect after modal is closed
		$('#orderSuccessModal').on('hidden.bs.modal', function () {
			window.location.href = 'product.html';
		});
	}
	
	// Show validation error toast
	function showValidationError(message) {
		// Remove existing toast if any
		$('#validationToast').remove();
		
		const toastHTML = `
			<div class="toast-container position-fixed top-0 start-50 translate-middle-x p-3" style="z-index: 9999; margin-top: 80px;">
				<div id="validationToast" class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
					<div class="toast-header bg-danger text-white">
						<i class="fas fa-exclamation-circle me-2"></i>
						<strong class="me-auto">Validation Error</strong>
						<button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
					</div>
					<div class="toast-body" style="font-size: 16px;">
						${message}
					</div>
				</div>
			</div>
		`;
		
		$('body').append(toastHTML);
		
		// Auto dismiss after 5 seconds
		setTimeout(() => {
			$('#validationToast').toast('hide');
			setTimeout(() => $('#validationToast').parent().remove(), 300);
		}, 5000);
	}
	
	// Show beautiful newsletter success modal
	function showNewsletterSuccess(email) {
		// Remove existing modal if any
		$('#newsletterSuccessModal').remove();
		
		// Create modal HTML
		const modalHTML = `
			<div class="modal fade" id="newsletterSuccessModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
						<div class="modal-body text-center p-5" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
							<div class="mb-4">
								<div style="width: 80px; height: 80px; background: white; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
									<i class="fas fa-envelope-open-text" style="font-size: 50px; color: #28a745;"></i>
								</div>
							</div>
							<h3 class="text-white mb-3" style="font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.2);">Successfully Subscribed!</h3>
							<div class="bg-white rounded p-4 mb-4" style="box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
								<p class="mb-2" style="font-size: 16px; color: #333;">
									Thank you for subscribing to our newsletter!
								</p>
								<p class="mb-0" style="font-size: 14px; color: #666;">
									A confirmation email has been sent to:<br>
									<strong style="color: #28a745;">${email}</strong>
								</p>
							</div>
							<p class="text-white mb-4" style="font-size: 16px; line-height: 1.6;">
								Stay tuned for the latest updates,<br>
								special offers, and delicious egg tart news! 🥧
							</p>
							<button type="button" class="btn btn-light btn-lg px-5 py-3 rounded-pill" data-bs-dismiss="modal" style="font-weight: 600; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
								<i class="fas fa-check me-2"></i>Got it!
							</button>
						</div>
					</div>
				</div>
			</div>
		`;
		
		// Add modal to body
		$('body').append(modalHTML);
		
		// Show modal
		const modal = new bootstrap.Modal(document.getElementById('newsletterSuccessModal'));
		modal.show();
	}
	
	// Show beautiful newsletter error modal
	function showNewsletterError(message) {
		// Remove existing modal if any
		$('#newsletterErrorModal').remove();
		
		// Create modal HTML
		const modalHTML = `
			<div class="modal fade" id="newsletterErrorModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
						<div class="modal-body text-center p-5" style="background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);">
							<div class="mb-4">
								<div style="width: 80px; height: 80px; background: white; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
									<i class="fas fa-exclamation-circle" style="font-size: 50px; color: #ffc107;"></i>
								</div>
							</div>
							<h3 class="text-white mb-3" style="font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.2);">Subscription Failed</h3>
							<div class="bg-white rounded p-4 mb-4" style="box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
								<p class="mb-0" style="font-size: 16px; color: #333; line-height: 1.6;">
									${message}
								</p>
							</div>
							<button type="button" class="btn btn-light btn-lg px-5 py-3 rounded-pill" data-bs-dismiss="modal" style="font-weight: 600; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
								<i class="fas fa-times me-2"></i>Close
							</button>
						</div>
					</div>
				</div>
			</div>
		`;
		
		// Add modal to body
		$('body').append(modalHTML);
		
		// Show modal
		const modal = new bootstrap.Modal(document.getElementById('newsletterErrorModal'));
		modal.show();
	}
	
	// Show beautiful error modal
	function showOrderErrorModal(message) {
		// Remove existing modal if any
		$('#orderErrorModal').remove();
		
		// Create modal HTML
		const modalHTML = `
			<div class="modal fade" id="orderErrorModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
						<div class="modal-body text-center p-5" style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);">
							<div class="mb-4">
								<div style="width: 80px; height: 80px; background: white; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
									<i class="fas fa-exclamation-triangle" style="font-size: 50px; color: #dc3545;"></i>
								</div>
							</div>
							<h3 class="text-white mb-3" style="font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.2);">Order Failed</h3>
							<div class="bg-white rounded p-4 mb-4" style="box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
								<p class="mb-0" style="font-size: 16px; color: #333; line-height: 1.6;">
									${message}
								</p>
							</div>
							<button type="button" class="btn btn-light btn-lg px-5 py-3 rounded-pill" data-bs-dismiss="modal" style="font-weight: 600; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
								<i class="fas fa-times me-2"></i>Close
							</button>
						</div>
					</div>
				</div>
			</div>
		`;
		
		// Add modal to body
		$('body').append(modalHTML);
		
		// Show modal
		const modal = new bootstrap.Modal(document.getElementById('orderErrorModal'));
		modal.show();
	}

	})(jQuery);

