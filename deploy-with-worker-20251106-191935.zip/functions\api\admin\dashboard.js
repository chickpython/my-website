// Admin Dashboard API
export async function onRequest({ request, env }) {
    // Handle CORS
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Content-Type': 'application/json'
    };

    if (request.method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    // Verify admin token
    const authHeader = request.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
            status: 401,
            headers: corsHeaders
        });
    }

    try {
        // If D1 database is available
        if (env.DB) {
            const today = new Date().toISOString().split('T')[0];
            
            // Get today's sales
            const todayOrders = await env.DB.prepare(
                'SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total FROM orders WHERE DATE(created_at) = ?'
            ).bind(today).first();

            // Get total products
            const totalProducts = await env.DB.prepare(
                'SELECT COUNT(*) as count FROM products WHERE is_active = 1'
            ).first();

            // Get total customers
            const totalCustomers = await env.DB.prepare(
                'SELECT COUNT(*) as count FROM customers'
            ).first();

            // Get pending orders
            const pendingOrders = await env.DB.prepare(
                'SELECT COUNT(*) as count FROM orders WHERE status = "pending"'
            ).first();

            // Get recent orders
            const recentOrders = await env.DB.prepare(
                'SELECT id, order_number, customer_name, total_amount, status, created_at, (SELECT COUNT(*) FROM order_items WHERE order_id = orders.id) as itemCount FROM orders ORDER BY created_at DESC LIMIT 10'
            ).all();

            // Get low stock items
            const lowStockItems = await env.DB.prepare(
                'SELECT name, stock FROM products WHERE stock < 20 AND is_active = 1'
            ).all();

            return new Response(JSON.stringify({
                totalSales: todayOrders.total || 0,
                totalOrders: todayOrders.count || 0,
                totalProducts: totalProducts.count || 0,
                totalCustomers: totalCustomers.count || 0,
                pendingOrders: pendingOrders.count || 0,
                recentOrders: recentOrders.results || [],
                lowStockItems: lowStockItems.results || []
            }), {
                headers: corsHeaders
            });
        }

        // Mock data if no database
        return new Response(JSON.stringify({
            totalSales: 450.50,
            totalOrders: 18,
            totalProducts: 3,
            totalCustomers: 142,
            pendingOrders: 5,
            recentOrders: [
                {
                    id: 1,
                    customerName: 'Sarah Tan',
                    itemCount: 3,
                    total: 58.50,
                    status: 'pending'
                }
            ],
            lowStockItems: [
                {
                    name: 'Cheese Egg Tart',
                    stock: 15
                }
            ]
        }), {
            headers: corsHeaders
        });

    } catch (error) {
        return new Response(JSON.stringify({ 
            error: 'Failed to fetch dashboard data',
            detail: error.message 
        }), {
            status: 500,
            headers: corsHeaders
        });
    }
}

