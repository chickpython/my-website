// Admin Panel JavaScript

// Sidebar Toggle
document.getElementById('sidebar-toggle')?.addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
});

// Logout Function - Show styled confirmation modal
function logout() {
    showLogoutModal();
}

// Show logout confirmation modal
function showLogoutModal() {
    // Remove existing modal if any
    const existingModal = document.getElementById('logoutModal');
    if (existingModal) {
        existingModal.remove();
    }
    const existingBackdrop = document.getElementById('logoutModalBackdrop');
    if (existingBackdrop) {
        existingBackdrop.remove();
    }
    
    // Create modal HTML
    const modalHTML = `
        <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true" style="display: block; z-index: 1060;">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content" style="border-radius: 15px; border: none; box-shadow: 0 10px 40px rgba(0,0,0,0.2);">
                    <div class="modal-body text-center p-5" style="background: linear-gradient(135deg, #f4b400 0%, #e89b00 100%); border-radius: 15px 15px 0 0;">
                        <div class="mb-4">
                            <div style="width: 80px; height: 80px; margin: 0 auto; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
                                <i class="fas fa-sign-out-alt" style="font-size: 2.5rem; color: #e89b00;"></i>
                            </div>
                        </div>
                        <h4 class="mb-3" style="color: white; font-weight: 600;">Confirm Logout</h4>
                        <p class="mb-0" style="color: rgba(255,255,255,0.9); font-size: 1rem;">Are you sure you want to logout?</p>
                    </div>
                    <div class="modal-footer justify-content-center p-4" style="border-top: none; background: white; border-radius: 0 0 15px 15px;">
                        <button type="button" class="btn btn-secondary rounded-pill px-4 py-2" onclick="closeLogoutModal()" style="min-width: 100px; border: 2px solid #dee2e6;">
                            <i class="fas fa-times me-2"></i>Cancel
                        </button>
                        <button type="button" class="btn btn-danger rounded-pill px-4 py-2" onclick="confirmLogout()" style="min-width: 100px; background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); border: none;">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show" id="logoutModalBackdrop" onclick="closeLogoutModal()" style="z-index: 1055;"></div>
    `;
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Animate modal in
    setTimeout(() => {
        const modal = document.getElementById('logoutModal');
        if (modal) {
            modal.classList.add('show');
        }
    }, 10);
    
    // Close on ESC key
    const escHandler = function(e) {
        if (e.key === 'Escape' || e.keyCode === 27) {
            closeLogoutModal();
            document.removeEventListener('keydown', escHandler);
        }
    };
    document.addEventListener('keydown', escHandler);
}

// Close logout modal
function closeLogoutModal() {
    const modal = document.getElementById('logoutModal');
    const backdrop = document.getElementById('logoutModalBackdrop');
    
    if (modal) {
        modal.classList.remove('show');
        if (backdrop) {
            backdrop.classList.remove('show');
        }
        setTimeout(() => {
            if (modal && modal.parentNode) {
                modal.parentNode.removeChild(modal);
            }
            if (backdrop && backdrop.parentNode) {
                backdrop.parentNode.removeChild(backdrop);
            }
        }, 300);
    }
}

// Confirm logout and redirect
function confirmLogout() {
    sessionStorage.removeItem('admin_token');
    sessionStorage.removeItem('admin_token_expires');
    sessionStorage.removeItem('admin_user');
    localStorage.removeItem('admin_seen_orders');
    window.location.href = 'login.html';
}

// Make functions globally accessible for onclick handlers
window.logout = logout;
window.showLogoutModal = showLogoutModal;
window.closeLogoutModal = closeLogoutModal;
window.confirmLogout = confirmLogout;

// Format Currency
function formatCurrency(amount) {
    return `RM ${parseFloat(amount).toFixed(2)}`;
}

// Format Date - Convert to Malaysia Time (MYT, UTC+8)
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    
    let date;
    
    // SQLite datetime format: "2025-11-06 14:30:00" (without timezone)
    // We need to treat this as UTC since SQLite stores in UTC
    // Check if it's SQLite format: "YYYY-MM-DD HH:MM:SS" (has space, no T, no Z, no +)
    if (dateString && dateString.includes(' ') && !dateString.includes('T') && !dateString.includes('Z') && !dateString.includes('+')) {
        // SQLite format: "2025-11-06 14:30:00" - replace space with T and append Z (UTC)
        date = new Date(dateString.replace(' ', 'T') + 'Z');
    } else if (dateString && dateString.includes('T') && !dateString.includes('Z') && !dateString.includes('+')) {
        // ISO format without timezone: "2025-11-06T14:30:00" - append Z (UTC)
        date = new Date(dateString + 'Z');
    } else {
        // Already has timezone info or other format - use as is
        date = new Date(dateString);
    }
    
    // Use toLocaleString with Malaysia timezone - this handles all conversions automatically
    return date.toLocaleString('en-MY', {
        timeZone: 'Asia/Kuala_Lumpur',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true // Use 12-hour format with AM/PM
    });
}

// Format Date with Time only (for separate time display if needed)
function formatTime(dateString) {
    if (!dateString) return 'N/A';
    
    let date;
    
    // SQLite datetime format: "2025-11-06 14:30:00" (without timezone)
    // We need to treat this as UTC since SQLite stores in UTC
    // Check if it's SQLite format: "YYYY-MM-DD HH:MM:SS" (has space, no T, no Z, no +)
    if (dateString && dateString.includes(' ') && !dateString.includes('T') && !dateString.includes('Z') && !dateString.includes('+')) {
        // SQLite format: "2025-11-06 14:30:00" - replace space with T and append Z (UTC)
        date = new Date(dateString.replace(' ', 'T') + 'Z');
    } else if (dateString && dateString.includes('T') && !dateString.includes('Z') && !dateString.includes('+')) {
        // ISO format without timezone: "2025-11-06T14:30:00" - append Z (UTC)
        date = new Date(dateString + 'Z');
    } else {
        // Already has timezone info or other format - use as is
        date = new Date(dateString);
    }
    
    return date.toLocaleTimeString('en-MY', {
        timeZone: 'Asia/Kuala_Lumpur',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true // Use 12-hour format with AM/PM
    });
}

// Show Loading
function showLoading(element) {
    element.innerHTML = `
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
}

// Show Error
function showError(message, container = null) {
    const alertHtml = `
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    if (container) {
        container.innerHTML = alertHtml;
    } else {
        // Show at top of content area
        const contentArea = document.querySelector('.content-area');
        contentArea.insertAdjacentHTML('afterbegin', alertHtml);
    }
}

// Show Success
function showSuccess(message, container = null) {
    const alertHtml = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    if (container) {
        container.innerHTML = alertHtml;
    } else {
        const contentArea = document.querySelector('.content-area');
        contentArea.insertAdjacentHTML('afterbegin', alertHtml);
    }
    
    // Auto-dismiss after 3 seconds
    setTimeout(() => {
        const alert = document.querySelector('.alert-success');
        if (alert) {
            alert.remove();
        }
    }, 3000);
}

// API Request Helper
async function apiRequest(endpoint, options = {}) {
    const token = sessionStorage.getItem('admin_token');
    
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        }
    };
    
    const finalOptions = { ...defaultOptions, ...options };
    
    try {
        const response = await fetch(endpoint, finalOptions);
        
        // Handle unauthorized
        if (response.status === 401) {
            sessionStorage.removeItem('admin_token');
            window.location.href = 'login.html';
            return null;
        }
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API Request Error:', error);
        throw error;
    }
}

// Confirm Delete
function confirmDelete(itemName, callback) {
    if (confirm(`Are you sure you want to delete "${itemName}"? This action cannot be undone.`)) {
        callback();
    }
}

// Table Search
function setupTableSearch(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    
    if (!input || !table) return;
    
    input.addEventListener('keyup', function() {
        const filter = input.value.toLowerCase();
        const rows = table.getElementsByTagName('tr');
        
        for (let i = 1; i < rows.length; i++) { // Skip header row
            const row = rows[i];
            const text = row.textContent.toLowerCase();
            
            if (text.includes(filter)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        }
    });
}

// Export to CSV
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const row = [], cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length - 1; j++) { // Skip action column
            row.push(cols[j].innerText);
        }
        
        csv.push(row.join(','));
    }
    
    // Download CSV
    const csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
    const downloadLink = document.createElement('a');
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}

// File Upload Preview
function setupImagePreview(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    
    if (!input || !preview) return;
    
    input.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });
}

// Initialize tooltips
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Check token expiration
function checkTokenExpiration() {
    const token = sessionStorage.getItem('admin_token');
    if (!token) return false;
    
    try {
        const decoded = atob(token);
        const parts = decoded.split(':');
        if (parts.length >= 2) {
            const expiresAt = parseInt(parts[1]);
            if (!isNaN(expiresAt) && Date.now() > expiresAt) {
                sessionStorage.removeItem('admin_token');
                sessionStorage.removeItem('admin_user');
                alert('Your session has expired. Please login again.');
                window.location.href = 'login.html';
                return false;
            }
        }
    } catch (e) {
        // Invalid token format
        sessionStorage.removeItem('admin_token');
        sessionStorage.removeItem('admin_user');
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    initTooltips();
    
    // Check token expiration on page load
    if (!checkTokenExpiration()) {
        return;
    }
    
    // Auto-logout on session timeout (24 hours to match token expiration)
    let logoutTimer;
    let inactivityTimer;
    let lastActivity = Date.now();
    
    function resetLogoutTimer() {
        clearTimeout(logoutTimer);
        // Token expires in 24 hours, but we'll also check inactivity
        logoutTimer = setTimeout(() => {
            if (!checkTokenExpiration()) {
                alert('Session expired. Please login again.');
                logout();
            }
        }, 24 * 60 * 60 * 1000); // 24 hours
    }
    
    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        lastActivity = Date.now();
        // Logout after 30 minutes of inactivity
        inactivityTimer = setTimeout(() => {
            alert('Session expired due to inactivity. Please login again.');
            logout();
        }, 30 * 60 * 1000); // 30 minutes
    }
    
    // Reset timers on user activity
    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    activityEvents.forEach(event => {
        document.addEventListener(event, () => {
            resetLogoutTimer();
            resetInactivityTimer();
        });
    });
    
    resetLogoutTimer();
    resetInactivityTimer();
    
    // Check token expiration every 5 minutes
    setInterval(() => {
        if (!checkTokenExpiration()) {
            logout();
        }
    }, 5 * 60 * 1000);
});

