// Cloudflare Pages Function: GET /api/products
// Returns list of active products for public display

export async function onRequest({ request, env }) {
  const cors = {
    'access-control-allow-origin': request.headers.get('origin') || '*',
    'access-control-allow-methods': 'GET, OPTIONS',
    'access-control-allow-headers': 'Content-Type, Authorization',
    'content-type': 'application/json'
  };

  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: cors });
  }

  if (request.method !== 'GET') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { 
      status: 405, 
      headers: cors 
    });
  }

  // Public request - return only active products
  if (env.DB) {
    try {
      const productsResult = await env.DB.prepare(
        `SELECT id, name, description, price, stock, category, image_url, sku, is_active 
         FROM products 
         WHERE is_active = 1 
         ORDER BY created_at DESC`
      ).all();

      return new Response(JSON.stringify({ 
        products: productsResult.results || [] 
      }), { 
        status: 200, 
        headers: cors 
      });
    } catch (error) {
      // If table doesn't exist, return empty array
      if (error.message && error.message.includes('no such table')) {
        return new Response(JSON.stringify({ products: [] }), { status: 200, headers: cors });
      }
      return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
        status: 500, 
        headers: cors 
      });
    }
  }

  // If no database, return empty array
  return new Response(JSON.stringify({ products: [] }), { status: 200, headers: cors });
}

