export default {
  async fetch(request, env, ctx) {
    try {
      const url = new URL(request.url);
      
      // CRITICAL: Log all requests for debugging
      console.log(`[WORKER] Request: ${request.method} ${url.pathname}`);
      
      // Security headers for all responses
      const securityHeaders = {
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'SAMEORIGIN',
        'X-XSS-Protection': '1; mode=block',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
        'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
        'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
        // Comprehensive CSP that allows all necessary resources - more permissive for images and assets
        'Content-Security-Policy': "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; script-src 'self' 'unsafe-inline' 'unsafe-eval' https:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: blob: https: *; font-src 'self' data: https:; connect-src 'self' https:; frame-src 'self' https:; object-src 'none'; base-uri 'self'; form-action 'self';"
      };
      
      const cors = {
        'access-control-allow-origin': request.headers.get('origin') || '*',
        'access-control-allow-methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'access-control-allow-headers': 'Content-Type, Authorization',
        'content-type': 'application/json',
        ...securityHeaders
      };

      // Helper function to log admin activities with detailed information
      async function logAdminActivity(env, username, action, details, request, responseStatus = null) {
        if (!env.DB) return;
        
        try {
          const clientIP = request.headers.get('CF-Connecting-IP') || 
                          request.headers.get('X-Forwarded-For') || 
                          'unknown';
          const userAgent = request.headers.get('User-Agent') || 'unknown';
          const endpoint = url.pathname;
          const method = request.method;
          
          // Get request data (for POST/PUT/PATCH requests)
          // Note: Request body can only be read once, so we'll log minimal info
          let requestData = null;
          if (['POST', 'PUT', 'PATCH'].includes(method)) {
            // For logging, we'll just note that data was sent
            // The actual body details are in the details parameter
            requestData = `[${method} request body]`;
          }
          
          // Generate session ID from token if available
          let sessionId = null;
          const authHeader = request.headers.get('Authorization');
          if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.substring(7);
            // Use first 16 chars of token hash as session ID
            sessionId = btoa(token).substring(0, 16);
          }
          
          await env.DB.prepare(
            `INSERT INTO admin_logs (
              admin_user, action, details, ip_address, user_agent, 
              endpoint, request_method, request_data, response_status, session_id, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`
          ).bind(
            username || 'unknown',
            action,
            details || null,
            clientIP,
            userAgent.length > 200 ? userAgent.substring(0, 200) : userAgent,
            endpoint,
            method,
            requestData,
            responseStatus,
            sessionId
          ).run();
        } catch (e) {
          // Silently fail if logging fails - don't break the main functionality
          console.error('Failed to log admin activity:', e.message);
        }
      }

      // Admin Login API with Security Protection
      if (url.pathname === '/api/admin/login') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }
        if (request.method !== 'POST') {
          return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
        }

        // Get client IP for rate limiting
        const clientIP = request.headers.get('CF-Connecting-IP') || 
                        request.headers.get('X-Forwarded-For') || 
                        'unknown';
        
        // Rate limiting: Check login attempts in last 15 minutes
        if (env.DB) {
          try {
            // Check failed login attempts in last 15 minutes for this IP
            const recentAttempts = await env.DB.prepare(
              `SELECT COUNT(*) as count FROM admin_logs 
               WHERE action = 'failed_login' 
               AND ip_address = ? 
               AND datetime(created_at) >= datetime('now', '-15 minutes')`
            ).bind(clientIP).first();
            
            const attemptCount = parseInt(recentAttempts?.count || 0);
            
            // Block if more than 5 failed attempts in 15 minutes
            if (attemptCount >= 5) {
              // Log blocked attempt with detailed info
              await logAdminActivity(env, 'unknown', 'blocked_login', `Too many failed attempts (${attemptCount} attempts)`, request, 429);
              
              return new Response(JSON.stringify({ 
                error: 'Too many failed login attempts. Please try again in 15 minutes.' 
              }), { status: 429, headers: cors });
            }
          } catch (e) {
            // If admin_logs table doesn't exist, continue without rate limiting
            console.log('Rate limiting check skipped:', e.message);
          }
        }

        const body = await request.json();
        const { username, password } = body;

        const ADMIN_USERNAME = env.ADMIN_USERNAME || 'admin';
        const ADMIN_PASSWORD = env.ADMIN_PASSWORD || 'Tartlicious2025!';

        if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
          // Generate secure token with expiration (24 hours)
          const expiresAt = Date.now() + (24 * 60 * 60 * 1000); // 24 hours
          const token = btoa(`${username}:${expiresAt}:${Math.random()}:${Date.now()}`);
          
          // Log successful login with detailed info
          await logAdminActivity(env, username, 'login_success', 'Admin login successful', request, 200);
          
          return new Response(JSON.stringify({
            success: true,
            token: token,
            user: username,
            expiresAt: expiresAt,
            message: 'Login successful'
          }), { status: 200, headers: cors });
        } else {
          // Log failed login attempt with detailed info
          await logAdminActivity(env, username || 'unknown', 'failed_login', 'Invalid credentials provided', request, 401);
          
          // Add delay to slow down brute force attacks
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          return new Response(JSON.stringify({ error: 'Invalid credentials' }), { status: 401, headers: cors });
        }
      }

      // Helper function to validate admin token
      function validateAdminToken(authHeader) {
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
          return { valid: false, error: 'No token provided' };
        }
        
        try {
          const token = authHeader.substring(7); // Remove 'Bearer '
          const decoded = atob(token);
          const parts = decoded.split(':');
          
          if (parts.length < 2) {
            return { valid: false, error: 'Invalid token format' };
          }
          
          // Check token expiration (if expiration is in token)
          const expiresAt = parseInt(parts[1]);
          if (!isNaN(expiresAt) && Date.now() > expiresAt) {
            return { valid: false, error: 'Token expired' };
          }
          
          return { valid: true, username: parts[0] };
        } catch (e) {
          return { valid: false, error: 'Invalid token' };
        }
      }

      // Admin Dashboard API
      if (url.pathname === '/api/admin/dashboard') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }
        
        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Dashboard access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }
        
        // Log successful dashboard access
        await logAdminActivity(env, validation.username, 'dashboard_access', 'Accessed dashboard overview', request, 200);

        console.log('=== DASHBOARD API CALLED ===');
        console.log('env.DB exists:', !!env.DB);
        console.log('env.DB type:', typeof env.DB);
        
        if (env.DB) {
          try {
            // Get ALL orders count first (simplest and most reliable)
            console.log('Attempting to query orders table...');
            
            let allOrdersCount = 0;
            let allOrdersResult = null;
            let queryError = null;
            
            try {
              // Try .first() method
              allOrdersResult = await env.DB.prepare(
                `SELECT COUNT(*) as count FROM orders`
              ).first();
              
              console.log('=== DASHBOARD DEBUG ===');
              console.log('All orders result (raw):', JSON.stringify(allOrdersResult));
              console.log('All orders result type:', typeof allOrdersResult);
              console.log('All orders result keys:', allOrdersResult ? Object.keys(allOrdersResult) : 'null');
              
              // If .first() returns null or unexpected format, try .all() as fallback
              if (!allOrdersResult || allOrdersResult.count === undefined) {
                console.log('Trying .all() method as fallback...');
                const allOrdersResultArray = await env.DB.prepare(
                  `SELECT COUNT(*) as count FROM orders`
                ).all();
                
                console.log('All orders result (from .all()):', JSON.stringify(allOrdersResultArray));
                
                if (allOrdersResultArray && allOrdersResultArray.results && allOrdersResultArray.results.length > 0) {
                  allOrdersResult = allOrdersResultArray.results[0];
                  console.log('Using first result from .all():', JSON.stringify(allOrdersResult));
                }
              }
              
              // Parse count - D1 returns { count: value }
              if (allOrdersResult) {
                if (allOrdersResult.count !== undefined) {
                  allOrdersCount = typeof allOrdersResult.count === 'number' 
                    ? allOrdersResult.count 
                    : parseInt(allOrdersResult.count) || 0;
                } else {
                  // Fallback: try to get first value if structure is different
                  const firstValue = Object.values(allOrdersResult)[0];
                  allOrdersCount = typeof firstValue === 'number' ? firstValue : parseInt(firstValue) || 0;
                }
              }
              
              console.log('All orders count (parsed):', allOrdersCount);
            } catch (queryErr) {
              queryError = queryErr;
              console.error('Error in orders count query:', queryErr);
              console.error('Error message:', queryErr.message);
              console.error('Error stack:', queryErr.stack);
            }
            
            if (queryError) {
              // Return error info in debug
              return new Response(JSON.stringify({
                totalSales: 0,
                totalOrders: 0,
                totalProducts: 0,
                totalCustomers: 0,
                pendingOrders: 0,
                recentOrders: [],
                lowStockItems: [],
                error: queryError.message,
                debug: {
                  queryError: queryError.toString(),
                  queryErrorMessage: queryError.message,
                  allOrdersResult: allOrdersResult,
                  allOrdersCount: allOrdersCount
                }
              }), { status: 200, headers: cors });
            }
            
            // Get all orders with dates for debugging
            let allOrdersWithDates = { results: [] };
            try {
              allOrdersWithDates = await env.DB.prepare(
                `SELECT id, order_number, created_at, strftime('%Y-%m-%d', created_at) as order_date, 
                        strftime('%H:%M:%S', created_at) as order_time
                 FROM orders 
                 ORDER BY created_at DESC 
                 LIMIT 5`
              ).all();
              
              console.log('Recent orders sample:', JSON.stringify(allOrdersWithDates.results));
            } catch (e) {
              console.error('Error fetching orders with dates:', e);
              allOrdersWithDates = { results: [] };
            }
            
            // For now, just show all orders (we can refine date filtering later)
            // This ensures orders are always shown if they exist
            let totalOrders = allOrdersCount || 0; // Ensure it's a number
            let totalSales = 0;
            
            console.log('Total orders before sales query:', totalOrders);
            
            if (totalOrders > 0) {
              try {
                // Get total sales for all orders
                const allSalesResult = await env.DB.prepare(
                  `SELECT COALESCE(SUM(total_amount), 0) as total FROM orders`
                ).first();
                
                console.log('Total sales result (raw):', JSON.stringify(allSalesResult));
                
                // Parse sales - handle both object and direct value
                if (allSalesResult) {
                  if (allSalesResult.total !== undefined) {
                    totalSales = typeof allSalesResult.total === 'number' 
                      ? allSalesResult.total 
                      : parseFloat(allSalesResult.total) || 0;
                  } else {
                    // Fallback: try to get first value if structure is different
                    const firstValue = Object.values(allSalesResult)[0];
                    totalSales = typeof firstValue === 'number' ? firstValue : parseFloat(firstValue) || 0;
                  }
                }
                
                console.log('Total sales (parsed):', totalSales);
              } catch (salesErr) {
                console.error('Error fetching total sales:', salesErr);
                totalSales = 0;
              }
            }
            
            console.log('Final count:', totalOrders);
            console.log('Final sales:', totalSales);
            console.log('========================');

            // Get pending orders count
            let pendingOrders = 0;
            try {
              const pendingResult = await env.DB.prepare(
                `SELECT COUNT(*) as count FROM orders WHERE status = 'pending'`
              ).first();
              
              console.log('Pending orders result (raw):', JSON.stringify(pendingResult));
              
              if (pendingResult) {
                if (typeof pendingResult === 'number') {
                  pendingOrders = pendingResult;
                } else if (pendingResult.count !== undefined) {
                  pendingOrders = typeof pendingResult.count === 'number' 
                    ? pendingResult.count 
                    : parseInt(pendingResult.count) || 0;
                } else {
                  // Fallback: try to get first value
                  const firstValue = Object.values(pendingResult)[0];
                  pendingOrders = typeof firstValue === 'number' ? firstValue : parseInt(firstValue) || 0;
                }
              }
              
              console.log('Pending orders (parsed):', pendingOrders);
            } catch (pendingErr) {
              console.error('Error fetching pending orders:', pendingErr);
              pendingOrders = 0;
            }

            // Get total products count (optional - table may not exist)
            let totalProducts = 0;
            try {
              const productsResult = await env.DB.prepare(
                `SELECT COUNT(*) as count FROM products`
              ).first();
              
              if (productsResult) {
                totalProducts = typeof productsResult === 'number' 
                  ? productsResult 
                  : (productsResult.count ? (typeof productsResult.count === 'number' ? productsResult.count : parseInt(productsResult.count)) : 0);
              }
            } catch (e) {
              console.log('Products table may not exist (this is OK):', e.message);
              // Set to 0 if table doesn't exist
              totalProducts = 0;
            }

            // Get total customers count (optional - table may not exist)
            let totalCustomers = 0;
            try {
              const customersResult = await env.DB.prepare(
                `SELECT COUNT(*) as count FROM customers`
              ).first();
              
              if (customersResult) {
                totalCustomers = typeof customersResult === 'number' 
                  ? customersResult 
                  : (customersResult.count ? (typeof customersResult.count === 'number' ? customersResult.count : parseInt(customersResult.count)) : 0);
              }
            } catch (e) {
              console.log('Customers table may not exist (this is OK):', e.message);
              // Set to 0 if table doesn't exist
              totalCustomers = 0;
            }

            // Get recent orders (last 5)
            let recentOrders = [];
            if (totalOrders > 0) {
              try {
                const recentOrdersResult = await env.DB.prepare(
                  `SELECT o.id, o.order_number, o.customer_name, o.total_amount, o.status, o.created_at,
                          (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as itemCount
                   FROM orders o 
                   ORDER BY o.created_at DESC 
                   LIMIT 5`
                ).all();
                
                console.log('Recent orders raw result:', JSON.stringify(recentOrdersResult));
                
                recentOrders = (recentOrdersResult.results || []).map(order => ({
                  id: order.id,
                  order_number: order.order_number || `#${order.id}`,
                  customerName: order.customer_name || 'Unknown',
                  itemCount: parseInt(order.itemCount) || 0,
                  total: parseFloat(order.total_amount) || 0,
                  status: order.status || 'pending',
                  created_at: order.created_at
                }));
                
                console.log('Recent orders processed:', recentOrders.length);
                console.log('Recent orders data:', JSON.stringify(recentOrders));
              } catch (e) {
                console.error('Error fetching recent orders:', e);
                recentOrders = [];
              }
            }

            // Get low stock items (stock < 10) - optional, table may not exist
            let lowStockItems = [];
            try {
              const lowStockResult = await env.DB.prepare(
                `SELECT id, name, stock FROM products WHERE stock < 10 AND is_active = 1 LIMIT 5`
              ).all();

              lowStockItems = (lowStockResult.results || []).map(item => ({
                id: item.id,
                name: item.name,
                stock: item.stock
              }));
            } catch (e) {
              console.log('Products table may not exist (this is OK):', e.message);
              // Set to empty array if table doesn't exist
              lowStockItems = [];
            }

            // Final validation - ensure allOrdersCount is a number
            if (typeof allOrdersCount !== 'number' || isNaN(allOrdersCount)) {
              console.error('WARNING: allOrdersCount is not a valid number:', allOrdersCount);
              allOrdersCount = 0;
            }
            
            // Ensure totalOrders matches allOrdersCount
            if (totalOrders === 0 && allOrdersCount > 0) {
              console.log('Fixing totalOrders to match allOrdersCount:', allOrdersCount);
              totalOrders = allOrdersCount;
            }
            
            console.log('=== FINAL RESPONSE VALUES ===');
            console.log('allOrdersCount:', allOrdersCount);
            console.log('totalOrders:', totalOrders);
            console.log('totalSales:', totalSales);
            console.log('recentOrders.length:', recentOrders.length);
            console.log('============================');
            
            return new Response(JSON.stringify({
              totalSales: parseFloat(totalSales) || 0,
              totalOrders: parseInt(totalOrders) || 0,
              totalProducts: parseInt(totalProducts) || 0,
              totalCustomers: parseInt(totalCustomers) || 0,
              pendingOrders: parseInt(pendingOrders) || 0,
              recentOrders: recentOrders,
              lowStockItems: lowStockItems,
              debug: {
                allOrdersCount: parseInt(allOrdersCount) || 0,
                finalCount: parseInt(totalOrders) || 0,
                finalSales: parseFloat(totalSales) || 0,
                recentOrdersCount: recentOrders.length || 0,
                recentOrdersSample: allOrdersWithDates?.results?.slice(0, 3) || [],
                dbConnected: true,
                queryResult: allOrdersResult ? 'success' : 'no result',
                allOrdersResultSample: allOrdersResult ? JSON.stringify(allOrdersResult).substring(0, 100) : 'null'
              }
            }), { status: 200, headers: cors });

          } catch (error) {
            console.error('Dashboard API error:', error);
            console.error('Error message:', error.message);
            console.error('Error stack:', error.stack);
            // Return error details in debug for troubleshooting
            return new Response(JSON.stringify({
              totalSales: 0,
              totalOrders: 0,
              totalProducts: 0,
              totalCustomers: 0,
              pendingOrders: 0,
              recentOrders: [],
              lowStockItems: [],
              error: error.message,
              debug: { 
                error: error.toString(),
                errorMessage: error.message,
                errorStack: error.stack,
                dbConnected: !!env.DB
              }
            }), { status: 200, headers: cors });
          }
        }

        // If no database, return empty data with debug info
        console.log('WARNING: env.DB is not defined!');
        return new Response(JSON.stringify({
          totalSales: 0,
          totalOrders: 0,
          totalProducts: 0,
          totalCustomers: 0,
          pendingOrders: 0,
          recentOrders: [],
          lowStockItems: [],
          error: 'Database not available',
          debug: { 
            message: 'Database not available (env.DB is undefined)',
            dbConnected: false,
            allOrdersCount: 0,
            finalCount: 0,
            finalSales: 0
          }
        }), { status: 200, headers: cors });
      }

      // Products API
      if (url.pathname === '/api/products') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const isAdminRequest = authHeader && authHeader.startsWith('Bearer ');
        
        // GET - Public (active products only) or Admin (all products)
        if (request.method === 'GET') {
          if (isAdminRequest) {
            // Admin request - check auth and return all products
            const validation = validateAdminToken(authHeader);
            if (!validation.valid) {
              await logAdminActivity(env, 'unknown', 'unauthorized_access', `Products API access denied: ${validation.error}`, request, 401);
              return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
            }
            
            await logAdminActivity(env, validation.username, 'products_view', 'Viewed products list', request, 200);
            
            if (env.DB) {
              try {
                const productsResult = await env.DB.prepare(
                  `SELECT * FROM products ORDER BY created_at DESC`
                ).all();

                return new Response(JSON.stringify({ 
                  products: productsResult.results || [] 
                }), { 
                  status: 200, 
                  headers: cors 
                });
              } catch (error) {
                console.error('Products API error:', error);
                if (error.message && error.message.includes('no such table')) {
                  return new Response(JSON.stringify({ products: [] }), { status: 200, headers: cors });
                }
                return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                  status: 500, 
                  headers: cors 
                });
              }
            }
            return new Response(JSON.stringify({ products: [] }), { status: 200, headers: cors });
          } else {
            // Public request - return only active products
            if (env.DB) {
              try {
                const productsResult = await env.DB.prepare(
                  `SELECT id, name, description, price, stock, category, image_url, sku, is_active 
                   FROM products 
                   WHERE is_active = 1 
                   ORDER BY created_at DESC`
                ).all();

                return new Response(JSON.stringify({ 
                  products: productsResult.results || [] 
                }), { 
                  status: 200, 
                  headers: cors 
                });
              } catch (error) {
                console.error('Products API error:', error);
                if (error.message && error.message.includes('no such table')) {
                  return new Response(JSON.stringify({ products: [] }), { status: 200, headers: cors });
                }
                return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                  status: 500, 
                  headers: cors 
                });
              }
            }
            return new Response(JSON.stringify({ products: [] }), { status: 200, headers: cors });
          }
        }

        // POST/PUT/DELETE - Admin only
        if (!isAdminRequest) {
          return new Response(JSON.stringify({ error: 'Authentication required' }), { status: 401, headers: cors });
        }

        const validation = validateAdminToken(authHeader);
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Products API access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        // POST - Add new product
        if (request.method === 'POST') {
          const product = await request.json();
          
          if (!product.name || !product.price) {
            await logAdminActivity(env, validation.username, 'product_add_failed', 'Failed to add product: Missing required fields', request, 400);
            return new Response(JSON.stringify({ error: 'Name and price are required' }), { status: 400, headers: cors });
          }

          if (env.DB) {
            try {
              // Generate SKU if not provided
              const sku = product.sku || `PROD-${Date.now()}`;
              
              const result = await env.DB.prepare(
                `INSERT INTO products (name, description, price, cost, stock, category, image_url, sku, is_active, created_at, updated_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`
              ).bind(
                product.name,
                product.description || '',
                product.price,
                product.cost || 0,
                product.stock || 0,
                product.category || '',
                product.image_url || '',
                sku,
                product.is_active !== undefined ? product.is_active : 1
              ).run();

              await logAdminActivity(env, validation.username, 'product_add', `Added product: ${product.name}`, request, 200);

              return new Response(JSON.stringify({ 
                success: true, 
                id: result.meta.last_row_id,
                message: 'Product added successfully' 
              }), { status: 200, headers: cors });
            } catch (error) {
              console.error('Add product error:', error);
              await logAdminActivity(env, validation.username, 'product_add_failed', `Error: ${error.message}`, request, 500);
              return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                status: 500, 
                headers: cors 
              });
            }
          }

          return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500, headers: cors });
        }

        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
      }

      // Update/Delete Product API
      if (url.pathname.startsWith('/api/products/') && url.pathname !== '/api/products') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Product management access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        const pathParts = url.pathname.split('/');
        const productId = pathParts[pathParts.length - 1];

        // PUT/PATCH - Update product
        if (request.method === 'PUT' || request.method === 'PATCH') {
          const product = await request.json();

          if (env.DB) {
            try {
              await env.DB.prepare(
                `UPDATE products 
                 SET name = ?, description = ?, price = ?, cost = ?, stock = ?, 
                     category = ?, image_url = ?, sku = ?, is_active = ?, updated_at = datetime('now')
                 WHERE id = ?`
              ).bind(
                product.name,
                product.description || '',
                product.price,
                product.cost || 0,
                product.stock || 0,
                product.category || '',
                product.image_url || '',
                product.sku || null,
                product.is_active !== undefined ? product.is_active : 1,
                productId
              ).run();

              await logAdminActivity(env, validation.username, 'product_update', `Updated product: ${product.name} (ID: ${productId})`, request, 200);

              return new Response(JSON.stringify({ 
                success: true, 
                message: 'Product updated successfully' 
              }), { status: 200, headers: cors });
            } catch (error) {
              console.error('Update product error:', error);
              await logAdminActivity(env, validation.username, 'product_update_failed', `Error: ${error.message}`, request, 500);
              return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                status: 500, 
                headers: cors 
              });
            }
          }

          return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500, headers: cors });
        }

        // DELETE - Delete product
        if (request.method === 'DELETE') {
          if (env.DB) {
            try {
              await env.DB.prepare(
                `DELETE FROM products WHERE id = ?`
              ).bind(productId).run();

              await logAdminActivity(env, validation.username, 'product_delete', `Deleted product ID: ${productId}`, request, 200);

              return new Response(JSON.stringify({ 
                success: true, 
                message: 'Product deleted successfully' 
              }), { status: 200, headers: cors });
            } catch (error) {
              console.error('Delete product error:', error);
              await logAdminActivity(env, validation.username, 'product_delete_failed', `Error: ${error.message}`, request, 500);
              return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                status: 500, 
                headers: cors 
              });
            }
          }

          return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500, headers: cors });
        }

        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
      }

      // Newsletter subscription API
      if (url.pathname === '/api/subscribe') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }
        if (request.method !== 'POST') {
          return new Response(JSON.stringify({ error: 'Method Not Allowed' }), { status: 405, headers: { ...cors, 'allow': 'POST, OPTIONS' } });
        }

        const contentType = request.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
          return new Response(JSON.stringify({ error: 'Invalid content type' }), { status: 415, headers: cors });
        }

        const body = await request.json();
        const toEmail = (body && body.email || '').trim();
        const turnstileToken = body && body.turnstileToken;
        
        if (!toEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(toEmail)) {
          return new Response(JSON.stringify({ error: 'Invalid email' }), { status: 400, headers: cors });
        }

        if (!turnstileToken) {
          return new Response(JSON.stringify({ error: 'Security verification required' }), { status: 400, headers: cors });
        }

        // Verify Turnstile token
        const TURNSTILE_SECRET_KEY = env.TURNSTILE_SECRET_KEY;
        if (!TURNSTILE_SECRET_KEY) {
          return new Response(JSON.stringify({ error: 'Turnstile not configured' }), { status: 500, headers: cors });
        }

        const turnstileVerify = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            secret: TURNSTILE_SECRET_KEY,
            response: turnstileToken
          })
        });

        const turnstileResult = await turnstileVerify.json();
        if (!turnstileResult.success) {
          return new Response(JSON.stringify({ error: 'Security verification failed' }), { status: 403, headers: cors });
        }

        const SERVICE_ID = env.EMAILJS_SERVICE_ID;
        const TEMPLATE_ID = env.EMAILJS_TEMPLATE_ID;
        const PUBLIC_KEY = env.EMAILJS_PUBLIC_KEY;
        const PRIVATE_KEY = env.EMAILJS_PRIVATE_KEY;
        if (!SERVICE_ID || !TEMPLATE_ID || !PUBLIC_KEY || !PRIVATE_KEY) {
          return new Response(JSON.stringify({ error: 'Server not configured' }), { status: 500, headers: cors });
        }

        // EmailJS: send email with Auto-Reply template (using private key for server-side)
        const payload = {
          service_id: SERVICE_ID,
          template_id: TEMPLATE_ID,
          user_id: PUBLIC_KEY,
          accessToken: PRIVATE_KEY,
          template_params: {
            to_email: toEmail,
            reply_to: toEmail
          }
        };

        const resp = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (!resp.ok) {
          const text = await resp.text();
          return new Response(JSON.stringify({ error: 'Email provider error', detail: text }), { status: 502, headers: cors });
        }

        return new Response(JSON.stringify({ ok: true }), { status: 200, headers: cors });
      }

      // Submit Order API
      if (url.pathname === '/api/orders/submit') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }
        if (request.method !== 'POST') {
          return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
        }

        const order = await request.json();
        
        // Validate order data
        if (!order.customerName || !order.customerPhone || !order.items || order.items.length === 0) {
          return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400, headers: cors });
        }

        // Generate order number
        const orderNumber = 'FLT' + new Date().toISOString().split('T')[0].replace(/-/g, '') + 
                           String(Date.now()).slice(-4);

        // If D1 database is available, save to database
        if (env.DB) {
          try {
            // Insert order
            const orderResult = await env.DB.prepare(
              `INSERT INTO orders (order_number, customer_name, customer_email, customer_phone, 
               delivery_address, total_amount, status, payment_status, payment_method, notes, created_at) 
               VALUES (?, ?, ?, ?, ?, ?, 'pending', 'pending', ?, ?, datetime('now'))`
            ).bind(
              orderNumber,
              order.customerName,
              order.customerEmail || '',
              order.customerPhone,
              order.deliveryAddress || 'Self Pickup',
              order.totalAmount,
              order.paymentMethod || 'Cash on Delivery',
              order.notes || ''
            ).run();

            const orderId = orderResult.meta.last_row_id;

            // Insert order items
            for (const item of order.items) {
              await env.DB.prepare(
                `INSERT INTO order_items (order_id, product_id, product_name, quantity, price, subtotal) 
                 VALUES (?, ?, ?, ?, ?, ?)`
              ).bind(
                orderId,
                item.id || 0,
                item.name,
                item.quantity,
                item.price,
                item.quantity * item.price
              ).run();
            }

            return new Response(JSON.stringify({ 
              success: true, 
              orderNumber: orderNumber,
              orderId: orderId,
              message: 'Order submitted successfully!',
              dbStatus: 'saved'
            }), { status: 200, headers: cors });

          } catch (dbError) {
            return new Response(JSON.stringify({ 
              success: true, 
              orderNumber: orderNumber,
              message: 'Order submitted (database error)',
              error: dbError.message,
              dbStatus: 'failed'
            }), { status: 200, headers: cors });
          }
        }

        // If no database, return success anyway (for testing)
        return new Response(JSON.stringify({ 
          success: true, 
          orderNumber: orderNumber,
          message: 'Order submitted successfully!',
          dbStatus: 'no-database'
        }), { status: 200, headers: cors });
      }

      // Customers API
      if (url.pathname === '/api/customers') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Customers API access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        // GET - Fetch all customers
        if (request.method === 'GET') {
          await logAdminActivity(env, validation.username, 'customers_view', 'Viewed customer list', request, 200);
          if (env.DB) {
            try {
              // Check if customers table exists first
              const tableCheck = await env.DB.prepare(
                `SELECT name FROM sqlite_master WHERE type='table' AND name='customers'`
              ).first();
              
              if (!tableCheck) {
                // Table doesn't exist, return empty array
                return new Response(JSON.stringify({ customers: [] }), { status: 200, headers: cors });
              }

              const customersResult = await env.DB.prepare(
                `SELECT * FROM customers ORDER BY created_at DESC`
              ).all();

              return new Response(JSON.stringify({ customers: customersResult.results || [] }), { 
                status: 200, 
                headers: cors 
              });
            } catch (error) {
              console.error('Customers API error:', error);
              // If table doesn't exist error, return empty array instead of error
              if (error.message && error.message.includes('no such table')) {
                return new Response(JSON.stringify({ customers: [] }), { status: 200, headers: cors });
              }
              return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                status: 500, 
                headers: cors 
              });
            }
          }
          return new Response(JSON.stringify({ customers: [] }), { status: 200, headers: cors });
        }

        // POST - Add new customer
        if (request.method === 'POST') {
          const customer = await request.json();
          
          if (!customer.name || !customer.phone) {
            await logAdminActivity(env, validation.username, 'customer_add_failed', 'Failed to add customer: Missing required fields', request, 400);
            return new Response(JSON.stringify({ error: 'Name and phone are required' }), { status: 400, headers: cors });
          }

          if (env.DB) {
            try {
              const result = await env.DB.prepare(
                `INSERT INTO customers (name, email, phone, address, total_orders, total_spent, tier, created_at) 
                 VALUES (?, ?, ?, ?, 0, 0, 'new', datetime('now'))`
              ).bind(
                customer.name,
                customer.email || '',
                customer.phone,
                customer.address || ''
              ).run();

              await logAdminActivity(env, validation.username, 'customer_add', `Added customer: ${customer.name}`, request, 200);

              return new Response(JSON.stringify({ 
                success: true, 
                id: result.meta.last_row_id,
                message: 'Customer added successfully' 
              }), { status: 200, headers: cors });
            } catch (error) {
              console.error('Add customer error:', error);
              return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                status: 500, 
                headers: cors 
              });
            }
          }

          return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500, headers: cors });
        }

        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
      }

      // Delete Customer API
      if (url.pathname.startsWith('/api/customers/') && url.pathname !== '/api/customers') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Customer delete access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        // Extract customer ID from path (e.g., /api/customers/123)
        const pathParts = url.pathname.split('/');
        const customerId = pathParts[pathParts.length - 1];

        if (request.method === 'DELETE') {
          if (env.DB) {
            try {
              // Check if customer exists
              const customerCheck = await env.DB.prepare(
                `SELECT id FROM customers WHERE id = ?`
              ).bind(customerId).first();

              if (!customerCheck) {
                await logAdminActivity(env, validation.username, 'customer_delete_failed', `Customer not found: ID ${customerId}`, request, 404);
                return new Response(JSON.stringify({ error: 'Customer not found' }), { status: 404, headers: cors });
              }

              // Delete customer
              await env.DB.prepare(
                `DELETE FROM customers WHERE id = ?`
              ).bind(customerId).run();

              await logAdminActivity(env, validation.username, 'customer_delete', `Deleted customer: ID ${customerId}`, request, 200);

              return new Response(JSON.stringify({ 
                success: true, 
                message: 'Customer deleted successfully' 
              }), { status: 200, headers: cors });
            } catch (error) {
              console.error('Delete customer error:', error);
              return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                status: 500, 
                headers: cors 
              });
            }
          }

          return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500, headers: cors });
        }

        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
      }

      // Update Order Status API
      if (url.pathname.startsWith('/api/orders/') && url.pathname !== '/api/orders' && url.pathname !== '/api/orders/submit') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Order update access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        // Extract order ID from path (e.g., /api/orders/123)
        const pathParts = url.pathname.split('/');
        const orderId = pathParts[pathParts.length - 1];

        if (request.method === 'PATCH' || request.method === 'PUT') {
          const body = await request.json();
          const { status, payment_status } = body;

          if (env.DB) {
            try {
              const updates = [];
              const params = [];

              if (status) {
                updates.push('status = ?');
                params.push(status);
              }

              if (payment_status) {
                updates.push('payment_status = ?');
                params.push(payment_status);
              }

              if (updates.length === 0) {
                await logAdminActivity(env, validation.username, 'order_update_failed', `Order ${orderId}: No fields to update`, request, 400);
                return new Response(JSON.stringify({ error: 'No fields to update' }), { status: 400, headers: cors });
              }

              params.push(orderId);
              const query = `UPDATE orders SET ${updates.join(', ')} WHERE id = ?`;

              await env.DB.prepare(query).bind(...params).run();

              const updateDetails = [];
              if (status) updateDetails.push(`status: ${status}`);
              if (payment_status) updateDetails.push(`payment: ${payment_status}`);
              await logAdminActivity(env, validation.username, 'order_update', `Order ${orderId}: ${updateDetails.join(', ')}`, request, 200);

              return new Response(JSON.stringify({ 
                success: true, 
                message: 'Order updated successfully' 
              }), { status: 200, headers: cors });
            } catch (error) {
              console.error('Update order error:', error);
              return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
                status: 500, 
                headers: cors 
              });
            }
          }

          return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500, headers: cors });
        }

        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
      }

      // Get Orders API (for admin panel)
      if (url.pathname === '/api/orders') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }
        
        if (request.method !== 'GET') {
          return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Orders API access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        await logAdminActivity(env, validation.username, 'orders_view', 'Viewed orders list', request, 200);

        if (env.DB) {
          try {
            // Fetch all orders
            const ordersResult = await env.DB.prepare(
              `SELECT * FROM orders 
               ORDER BY created_at DESC 
               LIMIT 100`
            ).all();

            const orders = ordersResult.results || [];

            // Fetch order items for each order
            const ordersWithItems = await Promise.all(
              orders.map(async (order) => {
                const itemsResult = await env.DB.prepare(
                  `SELECT * FROM order_items WHERE order_id = ?`
                ).bind(order.id).all();

                return {
                  ...order,
                  items: itemsResult.results || []
                };
              })
            );

            return new Response(JSON.stringify({ orders: ordersWithItems }), { 
              status: 200, 
              headers: cors 
            });
          } catch (error) {
            console.error('Orders API error:', error);
            return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
              status: 500, 
              headers: cors 
            });
          }
        }

        // Mock data if no database
        return new Response(JSON.stringify({ orders: [] }), { status: 200, headers: cors });
      }

      // Admin Logs API
      if (url.pathname === '/api/admin/logs') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }
        
        if (request.method !== 'GET') {
          return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Logs API access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        await logAdminActivity(env, validation.username, 'logs_view', 'Viewed security logs', request, 200);

        if (env.DB) {
          try {
            // Check if admin_logs table exists
            const tableCheck = await env.DB.prepare(
              `SELECT name FROM sqlite_master WHERE type='table' AND name='admin_logs'`
            ).first();
            
            if (!tableCheck) {
              return new Response(JSON.stringify({ logs: [] }), { status: 200, headers: cors });
            }

            const logsResult = await env.DB.prepare(
              `SELECT * FROM admin_logs 
               ORDER BY created_at DESC 
               LIMIT 500`
            ).all();

            return new Response(JSON.stringify({ logs: logsResult.results || [] }), { 
              status: 200, 
              headers: cors 
            });
          } catch (error) {
            console.error('Logs API error:', error);
            return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
              status: 500, 
              headers: cors 
            });
          }
        }

        return new Response(JSON.stringify({ logs: [] }), { status: 200, headers: cors });
      }

      // Clear Old Logs API
      if (url.pathname === '/api/admin/logs/clear') {
        if (request.method === 'OPTIONS') {
          return new Response(null, { status: 204, headers: cors });
        }
        
        if (request.method !== 'DELETE') {
          return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: cors });
        }

        const authHeader = request.headers.get('Authorization');
        const validation = validateAdminToken(authHeader);
        
        if (!validation.valid) {
          await logAdminActivity(env, 'unknown', 'unauthorized_access', `Clear logs access denied: ${validation.error}`, request, 401);
          return new Response(JSON.stringify({ error: validation.error || 'Unauthorized' }), { status: 401, headers: cors });
        }

        if (env.DB) {
          try {
            await env.DB.prepare(
              `DELETE FROM admin_logs 
               WHERE datetime(created_at) < datetime('now', '-30 days')`
            ).run();

            await logAdminActivity(env, validation.username, 'logs_clear', 'Cleared logs older than 30 days', request, 200);

            return new Response(JSON.stringify({ 
              success: true, 
              message: 'Old logs cleared successfully' 
            }), { status: 200, headers: cors });
          } catch (error) {
            console.error('Clear logs error:', error);
            return new Response(JSON.stringify({ error: 'Database error', detail: error.message }), { 
              status: 500, 
              headers: cors 
            });
          }
        }

        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500, headers: cors });
      }

      // Helper to detect file type from path
      function getFileType(pathname) {
        const ext = pathname.split('.').pop().toLowerCase();
        if (['css'].includes(ext)) return 'css';
        if (['js', 'mjs'].includes(ext)) return 'js';
        return null;
      }

      // CRITICAL: Let _redirects file handle admin HTML/CSS/JS files
      // Only intercept admin routes if they're API calls or if redirects fail
      // This allows Cloudflare Pages' _redirects file to work properly
      if (url.pathname.startsWith('/admin/')) {
        // Check if this is an API route (should be handled by worker)
        if (url.pathname.startsWith('/api/')) {
          // This is an API route, continue with worker handling
        } else {
          // This is a static file (HTML, CSS, JS, images)
          // Let Cloudflare Pages handle it via _redirects file
          // Only intercept if ASSETS is available and we need to verify the file
          console.log(`[WORKER] Admin static file detected: ${url.pathname} - letting _redirects handle it`);
          
          // For static admin files, let Cloudflare Pages serve them directly
          // The _redirects file should handle these with 200 status
          // Only fetch if we need to verify it's not index.html
          if (env.ASSETS) {
            // Quick check: fetch once to verify it's the correct file
            try {
              const staticResponse = await env.ASSETS.fetch(request, {
                cf: {
                  cacheEverything: false,
                  cacheTtl: 0
                }
              });
              
              if (staticResponse && staticResponse.status === 200) {
                const contentType = staticResponse.headers.get('Content-Type') || '';
                
                // If it's HTML, verify it's not index.html
                if (contentType.includes('text/html')) {
                  const cloned = staticResponse.clone();
                  const text = await staticResponse.text();
                  
                  // If it's homepage content, the redirects didn't work - handle it
                  if (text.includes('Fresh Egg Tarts Daily') && 
                      text.includes('We Bake Every Item') &&
                      !text.includes('Admin Login') &&
                      !text.includes('login-container')) {
                    console.error(`[WORKER] _redirects failed for ${url.pathname}, Cloudflare Pages serving index.html`);
                    // Fall through to worker handling below
                  } else {
                    // It's the correct admin file, return it
                    console.log(`[WORKER] _redirects working correctly for ${url.pathname}`);
                    const headers = new Headers(cloned.headers);
                    headers.set('Cache-Control', 'no-cache, no-store, must-revalidate, private');
                    headers.set('Pragma', 'no-cache');
                    headers.set('Expires', '0');
                    return new Response(cloned.body, {
                      status: 200,
                      headers: headers
                    });
                  }
                } else {
                  // Non-HTML file, return as-is
                  console.log(`[WORKER] _redirects working correctly for ${url.pathname} (${contentType})`);
                  const headers = new Headers(staticResponse.headers);
                  headers.set('Cache-Control', 'no-cache, no-store, must-revalidate, private');
                  headers.set('Pragma', 'no-cache');
                  headers.set('Expires', '0');
                  return new Response(staticResponse.body, {
                    status: 200,
                    headers: headers
                  });
                }
              } else {
                console.log(`[WORKER] Static file fetch returned status ${staticResponse?.status}, falling through to worker handling`);
              }
            } catch (e) {
              console.error(`[WORKER] Error checking static file:`, e);
              console.error(`[WORKER] Error stack:`, e.stack);
              // Fall through to worker handling
            }
          } else {
            console.log(`[WORKER] ASSETS not available, falling through to worker handling`);
          }
          
          // If we get here, either ASSETS isn't available or redirects failed
          // Fall through to worker handling below
        }
        
        // Continue with worker handling for admin routes
        console.log(`[WORKER] Admin route detected: ${url.pathname}`);
        // Extract the exact file path (e.g., /admin/login.html)
        const adminFilePath = url.pathname;
        
        // CRITICAL: If ASSETS is not available, return error immediately
        if (!env.ASSETS) {
          return new Response(`Admin file ${adminFilePath} not found - ASSETS binding not configured. Please configure ASSETS binding in Cloudflare Pages Functions settings.`, { 
            status: 500,
            headers: { 
              'Content-Type': 'text/html',
              'Cache-Control': 'no-cache, no-store, must-revalidate',
              'Pragma': 'no-cache',
              'Expires': '0',
              ...securityHeaders
            }
          });
        }
        
        try {
          // CRITICAL: Use the exact file path - don't modify it
          // Construct URL with explicit file path to bypass any Cloudflare Pages routing
          const adminFileUrl = new URL(adminFilePath, url.origin);
          
          // Create request with explicit headers to prevent SPA fallback
          const adminRequest = new Request(adminFileUrl.toString(), {
            method: request.method,
            headers: {
              'Accept': request.headers.get('Accept') || '*/*',
              'Cache-Control': 'no-cache',
              'X-Requested-File': adminFilePath,
              'X-Bypass-SPA': 'true'
            }
          });
          
          // CRITICAL: Try fetching the file directly without going through ASSETS.fetch
          // This bypasses Cloudflare Pages' SPA fallback behavior
          // Strategy: Try multiple URL patterns that might bypass the SPA fallback
          
          let response = null;
          const fetchStrategies = [
            // Strategy 1: Direct path with explicit file extension
            () => env.ASSETS.fetch(new Request(new URL(adminFilePath, url.origin).toString(), {
              method: 'GET',
              headers: {
                'Accept': '*/*',
                'Cache-Control': 'no-cache',
                'X-Requested-File': adminFilePath,
                'X-Bypass-SPA': 'true'
              }
            }), { cf: { cacheEverything: false, cacheTtl: 0 } }),
            
            // Strategy 2: With query param to bypass cache
            () => env.ASSETS.fetch(new Request(new URL(adminFilePath + '?v=' + Date.now(), url.origin).toString(), {
              method: 'GET',
              headers: {
                'Accept': '*/*',
                'Cache-Control': 'no-cache'
              }
            }), { cf: { cacheEverything: false, cacheTtl: 0 } }),
            
            // Strategy 3: Original request (fallback)
            () => env.ASSETS.fetch(adminRequest, {
              cf: {
                cacheEverything: false,
                cacheTtl: 0,
                cacheTtlByStatus: { '200': 0, '404': 0, '500': 0 }
              }
            })
          ];
          
          // Try each strategy until we get a valid response
          for (let i = 0; i < fetchStrategies.length; i++) {
            try {
              response = await fetchStrategies[i]();
              console.log(`[WORKER] Strategy ${i + 1} for ${adminFilePath}: status=${response?.status}, contentType=${response?.headers.get('Content-Type')}`);
              
              if (response && response.status === 200) {
                const testContentType = response.headers.get('Content-Type') || '';
                // If it's not HTML, we got the right file!
                if (!testContentType.includes('text/html')) {
                  console.log(`[WORKER] Strategy ${i + 1} succeeded! Got non-HTML file.`);
                  break;
                }
                
                // If it's HTML, check if it's the actual admin file or homepage
                if (testContentType.includes('text/html')) {
                  const clonedTest = response.clone();
                  const testText = await clonedTest.text();
                  const isAdminContent = testText.includes('Admin Login') || 
                                       testText.includes('login-container') ||
                                       testText.includes('Admin Panel') ||
                                       testText.includes('sidebar') ||
                                       testText.includes('admin_token') ||
                                       testText.includes('admin-style.css');
                  
                  if (isAdminContent) {
                    console.log(`[WORKER] Strategy ${i + 1} succeeded! Got admin HTML file.`);
                    // Reset response to use the cloned one
                    response = clonedTest;
                    break;
                  }
                  
                  // If it's homepage content, try next strategy
                  if (testText.includes('Fresh Egg Tarts Daily')) {
                    console.log(`[WORKER] Strategy ${i + 1} returned homepage, trying next...`);
                    response = null;
                    continue;
                  }
                }
              }
            } catch (e) {
              console.error(`[WORKER] Strategy ${i + 1} failed:`, e);
              response = null;
            }
          }
          
          // If all strategies failed, return error
          if (!response || response.status !== 200) {
            console.error(`[WORKER] All fetch strategies failed for ${adminFilePath}`);
            return new Response(`Admin file ${adminFilePath} not found. Cloudflare Pages is serving index.html instead. Please check that the file exists in your deployment and that _redirects file is configured correctly.`, { 
              status: 404,
              headers: { 
                'Content-Type': 'text/html',
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0',
                ...securityHeaders
              }
            });
          }
          
          console.log(`[WORKER] Final response for ${adminFilePath}: status=${response.status}, contentType=${response.headers.get('Content-Type')}`);
          
          // If we got a 200 response, verify it's the correct file
          if (response && response.status === 200) {
              const contentType = response.headers.get('Content-Type') || '';
              console.log(`[WORKER] Processing ${adminFilePath}, contentType: ${contentType}`);
              
              // For HTML files, verify content
              if (contentType.includes('text/html')) {
                console.log(`[WORKER] HTML file detected, checking content...`);
                // Clone response before reading to avoid consuming the body
                const clonedResponse = response.clone();
                const text = await response.text();
                console.log(`[WORKER] Content check - length: ${text.length}, has 'Admin Login': ${text.includes('Admin Login')}, has 'Fresh Egg Tarts': ${text.includes('Fresh Egg Tarts Daily')}`);
                
                // Check for admin-specific content - comprehensive detection for all admin pages
                // Check this FIRST before homepage detection
                const isAdminPage = 
                                   // Login page indicators
                                   text.includes('Admin Login') ||
                                   text.includes('login-container') ||
                                   text.includes('login-form') ||
                                   // Dashboard and admin panel indicators
                                   text.includes('Admin Panel') ||
                                   text.includes('sidebar') ||
                                   text.includes('main-content') ||
                                   // Admin script/style references
                                   text.includes('admin-script.js') ||
                                   text.includes('admin-style.css') ||
                                   text.includes('admin_token') ||
                                   // Path-based detection for admin routes
                                   (url.pathname.startsWith('/admin/') && (
                                     text.includes('Dashboard') ||
                                     text.includes('Inventory') ||
                                     text.includes('Orders') ||
                                     text.includes('Customers') ||
                                     text.includes('Analytics') ||
                                     text.includes('Security Logs')
                                   )) ||
                                   // Login page specific checks
                                   (url.pathname.includes('login.html') && (text.includes('password') || text.includes('username')));
                
                // If it's clearly an admin page, serve it immediately
                if (isAdminPage) {
                  // Use cloned response body instead of text to preserve original
                  return new Response(clonedResponse.body, {
                    status: 200,
                    headers: {
                      'Content-Type': 'text/html',
                      'Cache-Control': 'no-cache, no-store, must-revalidate, private',
                      'Pragma': 'no-cache',
                      'Expires': '0',
                      ...securityHeaders
                    }
                  });
                }
                
                // Only check for homepage if admin page indicators are NOT present
                // Use more specific homepage indicators to avoid false positives
                const isHomepage = text.includes('Fresh Egg Tarts Daily') && 
                                 text.includes('We Bake Every Item') &&
                                 text.includes('View Menu') &&
                                 !text.includes('Admin Login') &&
                                 !text.includes('login-container');
                
                // If it's clearly homepage content, Cloudflare Pages is serving index.html
                // We need to construct the actual file path and fetch it directly
                if (isHomepage) {
                  console.error(`[WORKER] Admin route ${url.pathname} returned homepage content (index.html), trying to fetch actual file...`);
                  
                  // CRITICAL: Try multiple strategies to get the actual file
                  // Strategy 1: Try with explicit file path in URL
                  const strategies = [
                    // Try 1: Direct file path with query param
                    new URL(adminFilePath + '?nocache=' + Date.now(), url.origin),
                    // Try 2: Direct file path without query
                    new URL(adminFilePath, url.origin),
                    // Try 3: Try with different Accept header
                    new URL(adminFilePath, url.origin)
                  ];
                  
                  for (let i = 0; i < strategies.length; i++) {
                    const strategyUrl = strategies[i];
                    console.log(`[WORKER] Trying strategy ${i + 1}: ${strategyUrl.toString()}`);
                    
                    const strategyRequest = new Request(strategyUrl.toString(), {
                      method: 'GET',
                      headers: {
                        'Cache-Control': 'no-cache',
                        'Accept': i === 2 ? 'text/html,application/xhtml+xml' : 'text/html',
                        'X-Requested-File': adminFilePath,
                        'X-Bypass-SPA-Fallback': 'true'
                      }
                    });
                    
                    const strategyResponse = await env.ASSETS.fetch(strategyRequest, {
                      cf: {
                        cacheEverything: false,
                        cacheTtl: 0
                      }
                    });
                    
                    if (strategyResponse && strategyResponse.status === 200) {
                      const strategyContentType = strategyResponse.headers.get('Content-Type') || '';
                      const strategyText = await strategyResponse.text();
                      const strategyIsAdmin = strategyText.includes('Admin Login') || 
                                            strategyText.includes('login-container') ||
                                            strategyText.includes('Admin Panel') ||
                                            strategyText.includes('sidebar') ||
                                            strategyText.includes('admin_token') ||
                                            strategyText.includes('admin-style.css');
                      
                      // If we got the actual admin file, return it
                      if (strategyIsAdmin) {
                        console.log(`[WORKER] Strategy ${i + 1} succeeded! Found admin file.`);
                        return new Response(strategyText, {
                          status: 200,
                          headers: {
                            'Content-Type': 'text/html',
                            'Cache-Control': 'no-cache, no-store, must-revalidate, private',
                            'Pragma': 'no-cache',
                            'Expires': '0',
                            ...securityHeaders
                          }
                        });
                      }
                      
                      // If still homepage, try next strategy
                      if (strategyText.includes('Fresh Egg Tarts Daily')) {
                        console.log(`[WORKER] Strategy ${i + 1} still returned homepage, trying next...`);
                        continue;
                      }
                    }
                  }
                  
                  // All strategies failed - Cloudflare Pages is serving index.html for admin routes
                  console.error(`[WORKER] All strategies failed. Cloudflare Pages is serving index.html for ${adminFilePath}`);
                  return new Response(`Admin file ${adminFilePath} not found. Cloudflare Pages is serving index.html instead. Please check Cloudflare Pages Settings → Builds & deployments and disable SPA mode.`, { 
                    status: 404,
                    headers: { 
                      'Content-Type': 'text/html',
                      'Cache-Control': 'no-cache, no-store, must-revalidate',
                      'Pragma': 'no-cache',
                      'Expires': '0',
                      ...securityHeaders
                    }
                  });
                }
                
                // If we can't determine if it's homepage or admin page, 
                // but the path is /admin/, try one more time to get the actual file
                // This handles cases where Cloudflare Pages serves index.html incorrectly
                if (url.pathname.startsWith('/admin/') && !isAdminPage && !isHomepage) {
                  // Might be homepage content that didn't match all indicators
                  // Try fetching the file directly one more time
                  const retryFileUrl = new URL(adminFilePath + '?nocache=' + Date.now(), url.origin);
                  const retryRequest = new Request(retryFileUrl.toString(), {
                    method: 'GET',
                    headers: {
                      'Cache-Control': 'no-cache',
                      'Accept': 'text/html',
                      'X-Requested-File': adminFilePath
                    }
                  });
                  
                  const retryResponse = await env.ASSETS.fetch(retryRequest, {
                    cf: {
                      cacheEverything: false,
                      cacheTtl: 0
                    }
                  });
                  
                  if (retryResponse && retryResponse.status === 200) {
                    const retryText = await retryResponse.text();
                    const retryIsAdmin = retryText.includes('Admin Panel') ||
                                        retryText.includes('sidebar') ||
                                        retryText.includes('Admin Login') ||
                                        retryText.includes('admin-style.css');
                    
                    if (retryIsAdmin) {
                      // Found the actual admin file!
                      return new Response(retryText, {
                        status: 200,
                        headers: {
                          'Content-Type': 'text/html',
                          'Cache-Control': 'no-cache, no-store, must-revalidate, private',
                          'Pragma': 'no-cache',
                          'Expires': '0',
                          ...securityHeaders
                        }
                      });
                    }
                  }
                }
                
                // It's the correct admin file (or we can't determine, so serve it anyway)
                // This prevents false positives when Google crawls the page
                // Use cloned response body since we've already read the original
                return new Response(clonedResponse.body, {
                  status: 200,
                  headers: {
                    'Content-Type': 'text/html',
                    'Cache-Control': 'no-cache, no-store, must-revalidate, private',
                    'Pragma': 'no-cache',
                    'Expires': '0',
                    ...securityHeaders
                  }
                });
              }
              
              // For non-HTML files (CSS, JS, images), verify they're not being served as HTML
              const expectedType = getFileType(adminFilePath);
              if (expectedType && contentType.includes('text/html')) {
                // This is wrong - CSS/JS/image file is being served as HTML (index.html)
                console.error(`[WORKER] Admin ${expectedType} file ${adminFilePath} is being served as HTML (index.html)`);
                
                // Try multiple strategies to get the actual file
                const fileStrategies = [
                  new URL(adminFilePath + '?file=' + Date.now(), url.origin),
                  new URL(adminFilePath + '?nocache=1', url.origin),
                  new URL(adminFilePath, url.origin)
                ];
                
                for (let i = 0; i < fileStrategies.length; i++) {
                  const fileUrl = fileStrategies[i];
                  console.log(`[WORKER] Trying file strategy ${i + 1} for ${expectedType}: ${fileUrl.toString()}`);
                  
                  const fileRequest = new Request(fileUrl.toString(), {
                    method: 'GET',
                    headers: {
                      'Cache-Control': 'no-cache',
                      'Accept': expectedType === 'css' ? 'text/css' : 
                               expectedType === 'js' ? 'application/javascript' : 
                               'image/*'
                    }
                  });
                  
                  const fileResponse = await env.ASSETS.fetch(fileRequest, {
                    cf: {
                      cacheEverything: false,
                      cacheTtl: 0
                    }
                  });
                  
                  if (fileResponse && fileResponse.status === 200) {
                    const fileContentType = fileResponse.headers.get('Content-Type') || '';
                    if (!fileContentType.includes('text/html')) {
                      // Got the correct file type!
                      console.log(`[WORKER] File strategy ${i + 1} succeeded! Got ${fileContentType}`);
                      const fileHeaders = new Headers(fileResponse.headers);
                      fileHeaders.set('Cache-Control', 'no-cache, no-store, must-revalidate, private');
                      fileHeaders.set('Pragma', 'no-cache');
                      fileHeaders.set('Expires', '0');
                      return new Response(fileResponse.body, {
                        status: 200,
                        statusText: fileResponse.statusText,
                        headers: fileHeaders
                      });
                    }
                  }
                }
                
                // All strategies failed
                console.error(`[WORKER] All file strategies failed. Cloudflare Pages serving index.html for ${adminFilePath}`);
                return new Response(`${expectedType.toUpperCase()} file ${adminFilePath} not found. Cloudflare Pages is serving index.html instead. Please check Cloudflare Pages Settings → Builds & deployments and disable SPA mode.`, { 
                  status: 404,
                  headers: { 
                    'Content-Type': expectedType === 'css' ? 'text/css' : expectedType === 'js' ? 'application/javascript' : 'image/jpeg',
                    'Cache-Control': 'no-cache, no-store, must-revalidate',
                    'Pragma': 'no-cache',
                    'Expires': '0'
                  }
                });
              }
              
              // For non-HTML files (CSS, JS), return with no-cache headers
              const headers = new Headers(response.headers);
              headers.set('Cache-Control', 'no-cache, no-store, must-revalidate, private');
              headers.set('Pragma', 'no-cache');
              headers.set('Expires', '0');
              return new Response(response.body, {
                status: response.status,
                statusText: response.statusText,
                headers: headers
              });
            }
            
            // If 404, return proper error
            if (response && response.status === 404) {
              return new Response(`Admin file ${adminFilePath} not found`, { 
                status: 404,
                headers: { 
                  'Content-Type': 'text/html',
                  'Cache-Control': 'no-cache, no-store, must-revalidate',
                  'Pragma': 'no-cache',
                  'Expires': '0',
                  ...securityHeaders
                }
              });
            }
            
            // Return response as-is for other status codes with cache headers
            const headers = new Headers(response.headers);
            headers.set('Cache-Control', 'no-cache, no-store, must-revalidate, private');
            headers.set('Pragma', 'no-cache');
            headers.set('Expires', '0');
            return new Response(response.body, {
              status: response.status,
              statusText: response.statusText,
              headers: headers
            });
                    } catch (e) {
                      console.error('Admin route fetch error:', e);
                      console.error('Error details:', {
                        path: adminFilePath,
                        error: e.message,
                        stack: e.stack
                      });
                      
                      return new Response(`Error loading admin file ${adminFilePath}: ${e.message}. Please check Cloudflare Pages Functions settings and ensure ASSETS binding is configured.`, { 
                        status: 500,
                        headers: { 
                          'Content-Type': 'text/html',
                          'Cache-Control': 'no-cache, no-store, must-revalidate',
                          'Pragma': 'no-cache',
                          'Expires': '0',
                          ...securityHeaders
                        }
                      });
                    }
      }

      // CRITICAL: For non-API routes, let Cloudflare Pages handle them naturally
      // This ensures CSS/JS files get correct MIME types from Pages without worker interference
      // Only add security headers if ASSETS is available, otherwise let Pages serve directly
      if (env.ASSETS) {
        try {
          const response = await env.ASSETS.fetch(request);
          if (response) {
            // CRITICAL FIX: If 404 for CSS/JS file, return empty content with correct Content-Type
            // This prevents browsers from trying to parse HTML 404 pages as CSS/JS
            if (response.status === 404) {
              const fileType = getFileType(url.pathname);
              if (fileType === 'css') {
                return new Response('/* File not found */', {
                  status: 404,
                  headers: {
                    'Content-Type': 'text/css',
                    'Cache-Control': 'no-cache'
                  }
                });
              }
              if (fileType === 'js') {
                return new Response('// File not found', {
                  status: 404,
                  headers: {
                    'Content-Type': 'application/javascript',
                    'Cache-Control': 'no-cache'
                  }
                });
              }
              // For HTML 404s, return original response (Pages handles it correctly)
              return response;
            }
            // For successful responses (non-admin), add security headers but preserve Content-Type
            const newHeaders = new Headers(response.headers);
            Object.entries(securityHeaders).forEach(([key, value]) => {
              newHeaders.set(key, value);
            });
            return new Response(response.body, {
              status: response.status,
              statusText: response.statusText,
              headers: newHeaders
            });
          }
        } catch (e) {
          console.error('ASSETS fetch error:', e);
          // On error, return empty CSS/JS if that's what was requested
          const fileType = getFileType(url.pathname);
          if (fileType === 'css') {
            return new Response('/* File not found */', {
              status: 404,
              headers: { 'Content-Type': 'text/css' }
            });
          }
          if (fileType === 'js') {
            return new Response('// File not found', {
              status: 404,
              headers: { 'Content-Type': 'application/javascript' }
            });
          }
        }
      }
      
      // If ASSETS not available, return empty CSS/JS if that's what was requested
      const fileType = getFileType(url.pathname);
      if (fileType === 'css') {
        return new Response('/* File not found */', {
          status: 404,
          headers: { 'Content-Type': 'text/css' }
        });
      }
      if (fileType === 'js') {
        return new Response('// File not found', {
          status: 404,
          headers: { 'Content-Type': 'application/javascript' }
        });
      }
      // For HTML and other files, return 404 (let Pages handle routing)
      return new Response('Not Found', { 
        status: 404,
        headers: {
          'Content-Type': 'text/plain',
          ...securityHeaders
        }
      });
    } catch (err) {
      console.error('[WORKER] Unhandled error:', err);
      console.error('[WORKER] Error message:', err.message);
      console.error('[WORKER] Error stack:', err.stack);
      return new Response(`Internal Error: ${err.message}`, { 
        status: 500,
        headers: {
          'Content-Type': 'text/html',
          'Cache-Control': 'no-cache'
        }
      });
    }
  }
};


