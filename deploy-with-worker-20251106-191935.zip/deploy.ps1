# Cloudflare Pages Deployment Script
# This script creates a ZIP file excluding unnecessary files

Write-Host "Creating deployment package..." -ForegroundColor Cyan

# Get current directory
$projectRoot = Get-Location
$zipName = "deploy-with-worker-$(Get-Date -Format 'yyyyMMdd-HHmmss').zip"

Write-Host "Project root: $projectRoot" -ForegroundColor Yellow
Write-Host "ZIP file: $zipName" -ForegroundColor Yellow

# Check if _worker.js exists
if (-not (Test-Path "_worker.js")) {
    Write-Host "ERROR: _worker.js not found in current directory!" -ForegroundColor Red
    Write-Host "   Make sure you're in the project root directory." -ForegroundColor Red
    exit 1
}

Write-Host "Found _worker.js" -ForegroundColor Green

# Remove old deployment ZIPs if they exist
Get-ChildItem -Filter "deploy-with-worker-*.zip" | Remove-Item -Force
Write-Host "Cleaned up old deployment files" -ForegroundColor Yellow

# Create temporary directory for files to zip
$tempDir = Join-Path $env:TEMP "deploy-temp-$(Get-Date -Format 'yyyyMMddHHmmss')"
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
Write-Host "Created temporary directory" -ForegroundColor Gray

# Copy files excluding unnecessary ones
Write-Host "Copying files (excluding unnecessary files)..." -ForegroundColor Yellow
Write-Host "   Excluding: node_modules, scss, *.md, *.zip, *.rar, *.sql, etc." -ForegroundColor Gray

Get-ChildItem -Path . -Recurse -File | Where-Object {
    $fullPath = $_.FullName
    $relativePath = $fullPath.Replace("$projectRoot\", "").Replace("$projectRoot", "")
    
    # Exclude patterns
    $exclude = $false
    
    # Exclude folders
    if ($relativePath -like "node_modules\*" -or 
        $relativePath -like "scss\*" -or
        $relativePath -like ".git\*" -or
        $relativePath -like "deploy-with-worker-*.zip") {
        $exclude = $true
    }
    
    # Exclude file types
    if ($_.Extension -eq ".md" -or
        $_.Extension -eq ".zip" -or
        $_.Extension -eq ".rar" -or
        $_.Extension -eq ".sql" -or
        $_.Name -eq "wrangler.toml") {
        $exclude = $true
    }
    
    if (-not $exclude) {
        $destPath = Join-Path $tempDir $relativePath
        $destFolder = Split-Path $destPath -Parent
        if (-not (Test-Path $destFolder)) {
            New-Item -ItemType Directory -Path $destFolder -Force | Out-Null
        }
        Copy-Item $fullPath -Destination $destPath -Force
    }
    
    return -not $exclude
} | Out-Null

# Create ZIP file
Write-Host "Creating ZIP file..." -ForegroundColor Yellow
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipName -Force

# Clean up temp directory
Remove-Item $tempDir -Recurse -Force
Write-Host "Cleaned up temporary directory" -ForegroundColor Gray

# Verify _worker.js is in the ZIP
Write-Host "Verifying ZIP contents..." -ForegroundColor Yellow
Add-Type -AssemblyName System.IO.Compression.FileSystem
$verifyZip = [System.IO.Compression.ZipFile]::OpenRead("$projectRoot\$zipName")
$workerFile = $verifyZip.Entries | Where-Object { $_.Name -eq "_worker.js" -and $_.FullName -eq "_worker.js" }

if ($workerFile) {
    Write-Host "SUCCESS: _worker.js is in ZIP at root level!" -ForegroundColor Green
} else {
    Write-Host "WARNING: _worker.js not found at root in ZIP!" -ForegroundColor Yellow
    Write-Host "   Checking ZIP contents..." -ForegroundColor Yellow
    $verifyZip.Entries | Where-Object { $_.Name -like "*worker*" } | ForEach-Object {
        Write-Host "   Found: $($_.FullName)" -ForegroundColor Yellow
    }
}

$zipFileCount = $verifyZip.Entries.Count
$zipFileSize = (Get-Item $zipName).Length / 1MB
Write-Host "ZIP contains $zipFileCount files, Size: $([math]::Round($zipFileSize, 2)) MB" -ForegroundColor Cyan
$verifyZip.Dispose()

Write-Host ""
Write-Host "ZIP file created: $zipName" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "   1. Go to Cloudflare Dashboard - Pages - Your project" -ForegroundColor White
Write-Host "   2. Click Create deployment" -ForegroundColor White
Write-Host "   3. Select Upload assets" -ForegroundColor White
Write-Host "   4. Upload the ZIP file shown above" -ForegroundColor White
Write-Host "   5. Wait for deployment to complete" -ForegroundColor White
Write-Host ""
Write-Host "Done!" -ForegroundColor Green
