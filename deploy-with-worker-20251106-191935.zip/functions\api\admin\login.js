// Admin Login API
export async function onRequest({ request, env }) {
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
        return new Response(null, {
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Max-Age': '86400',
            },
        });
    }

    if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), {
            status: 405,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' 
            },
        });
    }

    try {
        const { username, password } = await request.json();

        // Get admin credentials from environment variables
        const ADMIN_USERNAME = env.ADMIN_USERNAME || 'admin';
        const ADMIN_PASSWORD = env.ADMIN_PASSWORD || 'FingerLickinTart2025!';

        if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
            // Generate simple session token (In production, use JWT)
            const token = btoa(`${username}:${Date.now()}:${Math.random()}`);
            
            return new Response(JSON.stringify({
                success: true,
                token: token,
                user: username,
                message: 'Login successful'
            }), {
                status: 200,
                headers: { 
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
            });
        } else {
            return new Response(JSON.stringify({ 
                error: 'Invalid credentials' 
            }), {
                status: 401,
                headers: { 
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
            });
        }
    } catch (error) {
        return new Response(JSON.stringify({ 
            error: 'Login failed', 
            detail: error.message 
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
        });
    }
}

